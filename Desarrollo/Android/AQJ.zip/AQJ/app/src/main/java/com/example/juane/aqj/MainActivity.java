package com.example.juane.aqj;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button RegistrarseBtn = (Button) findViewById(R.id.RegistrarseBtn);
        RegistrarseBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent startIntent = new Intent(getApplicationContext(), registrarse.class);
                startActivity(startIntent);
            }
        });

        Button IniciarSesionBtn = (Button) findViewById(R.id.IniciarSesionBtn);
        IniciarSesionBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent startIntent = new Intent(getApplicationContext(), IniciarSesion.class);
                startActivity(startIntent);
            }
        });
    }
}
