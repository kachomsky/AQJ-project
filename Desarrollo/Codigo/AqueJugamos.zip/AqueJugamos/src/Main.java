
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import com.mysql.jdbc.jdbc2.optional.MysqlDataSource;


public class Main {

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
				
				AplicacioBD bd = new AplicacioBD();
				bd. mostrarJocs();
				bd.carregarJocsAlternatius();
				bd.carregarJocsTaula();
				//registrarse(bd);
				bd.carregarUsuaris();
				bd.consultaDadesUsuari();
				//login(bd);
				
				
				
				

			}
	
	public static void registrarse(AplicacioBD bd) throws SQLException
	{
		Scanner lector = new Scanner(System.in);
		System.out.println("Inserta el nom d'usuari");
		String nomUsuari = lector.next();
		System.out.println(nomUsuari);
		System.out.println("Inserta contrasenya");
		String password = lector.next();
		System.out.println("*********");
		System.out.println("Inserta e-mail");
		String mail = lector.next();
		System.out.println(mail);
		bd.insertarDadesUsuari(nomUsuari, password, mail);
		
	}
	public static void login(AplicacioBD bd)
	{
		boolean login = false;
		Scanner lector = new Scanner(System.in);
		System.out.println("Inserta e-mail");
		String mail = lector.next();
		System.out.println("Inserta el password");
		String password = lector.next();
		login = bd.comprobarUsuari(mail,password);
		if (login)
		{
			System.out.println("Estas dins");
		}
		else
		{
			System.out.println("Camps incorrectes");
		}
		
	}


	}

	

