
public class Usuari {

	private int idUsuari;
	private String nomUsuari;
	private String password;
	private String mail;
	private int activo;
	private int bloqueado;
	private int isAdmin;
	private String grupo;
	private AplicacioBD bd;
	
	public int getIdUsuari() {
		return idUsuari;
	}

	public void setIdUsuari(int idUsuari) {
		this.idUsuari = idUsuari;
	}

	public String getNomUsuari() {
		return nomUsuari;
	}

	public void setNomUsuari(String nomUsuari) {
		this.nomUsuari = nomUsuari;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getMail() {
		return mail;
	}

	public void setMail(String mail) {
		this.mail = mail;
	}

	public int getActivo() {
		return activo;
	}

	public void setActivo(int activo) {
		this.activo = activo;
	}

	public int getBloqueado() {
		return bloqueado;
	}

	public void setBloqueado(int bloqueado) {
		this.bloqueado = bloqueado;
	}

	public int getIsAdmin() {
		return isAdmin;
	}

	public void setIsAdmin(int isAdmin) {
		this.isAdmin = isAdmin;
	}

	public String getGrupo() {
		return grupo;
	}

	public void setGrupo(String grupo) {
		this.grupo = grupo;
	}

	public Usuari(int idUsuari, String nomUsuari, String password, String mail, int activo, int bloqueado, int isAdmin,
			String grupo) {
		super();
		this.idUsuari = idUsuari;
		this.nomUsuari = nomUsuari;
		this.password = password;
		this.mail = mail;
		this.activo = activo;
		this.bloqueado = bloqueado;
		this.isAdmin = isAdmin;
		this.grupo = grupo;
	}
	
	

	
	
	
	
	
	
	
}
