package nucli.com.aquejugamos.DAO;
import nucli.com.aquejugamos.general.Usuari;
import nucli.com.aquejugamos.general.Partida;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Map;

public interface PartidaDAO {
	//public boolean pujarPartida(Partida p);
	public boolean pujarPartida(Partida p, ArrayList<Integer> puntuaciones);
	public int obtindreIdUltimaPartida(String hora);
	public Map mostrarPartidesUsuari(int idUsuari) throws SQLException;
	public boolean etiquetarUsuario(Usuari u, Partida p, int puntos);
}
