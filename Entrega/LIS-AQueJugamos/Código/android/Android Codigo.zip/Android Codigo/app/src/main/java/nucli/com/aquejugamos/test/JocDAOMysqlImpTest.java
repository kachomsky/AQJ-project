package nucli.com.aquejugamos.test;

import static org.junit.Assert.*;

import org.junit.Test;

import nucli.com.aquejugamos.DAO.DAOFactory;
import nucli.com.aquejugamos.DAO.JocAlternatiuDAO;
import nucli.com.aquejugamos.DAO.JocDAO;

public class JocDAOMysqlImpTest {
	
	DAOFactory mysqlFactory = DAOFactory.getDAOFactory(DAOFactory.MYSQLTEST);
	JocDAO jocDAO = mysqlFactory.getJocDAO();
	
	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
