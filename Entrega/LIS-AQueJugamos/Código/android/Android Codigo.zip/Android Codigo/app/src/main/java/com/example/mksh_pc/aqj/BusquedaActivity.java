package com.example.mksh_pc.aqj;

import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;

import nucli.com.aquejugamos.DAO.DAOFactory;
import nucli.com.aquejugamos.DAO.JocDAO;
import nucli.com.aquejugamos.general.Joc;

public class BusquedaActivity extends AppCompatActivity implements View.OnClickListener{

    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_busqueda);

        Button botonBusqueda = (Button) findViewById(R.id.busqueda);
        botonBusqueda.setOnClickListener(this);

        //findViewById(R.id.appBarTop).setDisplayHomeAsUpEnabled(true);
        //getSupportActionBar().setTitle("Búsqueda");

        spinnerCategory();
        spinnerGenre();

    }

    private void spinnerCategory() {

        ArrayList<String> st = new ArrayList<>();
        st.add("Todos");
        try{
            ArrayList<String> getCategorias = new getCategorias().execute().get();

            for(String categoria : getCategorias)
                st.add(categoria);
        }catch (Exception e){
            Log.e("BUSQUEDA", "Error al recoger las categorias");
        }

        final ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, st);

        Spinner spinner = findViewById(R.id.spinnerCategory);
        spinner.setAdapter(adapter);
    }

    private void spinnerGenre() {

        ArrayList<String> st = new ArrayList<>();
        st.add("Todos");
        try{
            ArrayList<String> getCategorias = new getTipos().execute().get();

            for(String categoria : getCategorias)
                st.add(categoria);
        }catch (Exception e){
            Log.e("BUSQUEDA", "Error al recoger los generos");
        }

        final ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, st);

        Spinner spinner = findViewById(R.id.spinnerGenre);
        spinner.setAdapter(adapter);
    }

    @Override
    public void onClick(View v) {

        switch(v.getId()) {
            case R.id.busqueda:
                Log.d("BUSQUEDA", "Boton busqueda seleccionado");
                Log.d("BUSQUEDA", "Realizando búsqueda");
                EditText nombreJuegoEdit = (EditText) findViewById(R.id.editGameName);
                String nombreJuego = nombreJuegoEdit.getText().toString();

                Spinner spinnerCategoria = (Spinner) findViewById(R.id.spinnerCategory);
                String nombreCategoria = spinnerCategoria.getSelectedItem().toString();


                EditText numeroJugadoresEdit = (EditText) findViewById(R.id.editGamePlayers);
                String numeroJugadores = numeroJugadoresEdit.getText().toString();

                EditText duracionEdit = (EditText) findViewById(R.id.editGameTime);
                String duracion = duracionEdit.getText().toString();

                Spinner spinnerGenero = (Spinner) findViewById(R.id.spinnerGenre);
                String nombreGenero = spinnerGenero.getSelectedItem().toString();

                if(nombreCategoria.equals("Todos")){
                    nombreCategoria = "";
                }

                if(nombreGenero.equals("Todos")){
                    nombreGenero = "";
                }

                ArrayList<Joc> juegosEncontrados = new ArrayList<>();

                Log.d("BUSQUEDA", "PARAMETROS DE BUSQUEDA");
                Log.d("BUSQUEDA", "Nombre: " + nombreJuego);
                Log.d("BUSQUEDA", "Categoria: " + nombreCategoria);
                Log.d("BUSQUEDA", "Numero jugadores: " + numeroJugadores);
                Log.d("BUSQUEDA", "Duracion: " + duracion);
                Log.d("BUSQUEDA", "Genero: " + nombreGenero);

                try{
                    juegosEncontrados = new busquedaJuegos(nombreJuego, numeroJugadores, duracion, nombreCategoria, nombreGenero).execute().get();
                }catch(Exception e){
                    Log.e("BUSQUEDA", "Error al recoger los valores de la busqueda");
                }

                if(juegosEncontrados.size() > 0) {
                    Log.d("BUSQUEDA", "Juegos encontrados:");
                    Toast.makeText(BusquedaActivity.this, "Se han encontrado los siguientes juegos", Toast.LENGTH_LONG).show();
                    for (Joc j : juegosEncontrados) {
                        Log.d("BUSQUEDA", j.getNomJoc());
                    }
                    /*Bundle bundle = new Bundle();
                    bundle.putParcelableArrayList("juegosEncontrados", juegosEncontrados);
                    Fragment fragInfo = new JuegosFragment();
                    fragInfo.setArguments(bundle);
                    android.support.v4.app.FragmentManager fragmentManager = getSupportFragmentManager();
                    final android.support.v4.app.FragmentTransaction transaction = fragmentManager.beginTransaction();
                    transaction.replace(R.id.activity_crear_nova_tasca, fragInfo).commit();*/


                    //FragmentTransaction ft = fragmentManager.beginTransaction();
                    //ft.replace(R.id.yourFragmentContainer, fragment).commit();
                    Intent intent = new Intent(this, MainActivity.class);
                    intent.putParcelableArrayListExtra("juegosEncontrados", juegosEncontrados);
                    intent.putExtra("opcion","listaJuegos");
                    startActivity(intent);

                }
                else{
                    Log.i("BUSQUEDA","No se ha encontrado ningún juego");
                    Toast.makeText(BusquedaActivity.this, "No se han encontrado resultados con esos parámetros", Toast.LENGTH_LONG).show();
                }

                break;
        }

    }

    private class getCategorias extends AsyncTask<Void, Void, ArrayList> {

        @Override
        protected ArrayList<String> doInBackground(Void... voids) {

            Log.d("BUSQUEDA", "Cargando categorias");
            DAOFactory daoFactory = DAOFactory.getDAOFactory(DAOFactory.MYSQL);
            JocDAO jocDAO = daoFactory.getJocDAO();
            ArrayList<String> categorias = jocDAO.getTodasCategorias();
            Log.d("BUSQUEDA", "Categorias cargadas");

            return categorias;
        }
    }

    private class getTipos extends AsyncTask<Void, Void, ArrayList> {

        @Override
        protected ArrayList<String> doInBackground(Void... voids) {
            Log.d("BUSQUEDA", "Cargando generos");
            DAOFactory daoFactory = DAOFactory.getDAOFactory(DAOFactory.MYSQL);
            JocDAO jocDAO = daoFactory.getJocDAO();
            ArrayList<String> categorias = jocDAO.getTodosTipos();
            Log.d("BUSQUEDA", "Categorias generos");

            return categorias;
        }
    }

    private class busquedaJuegos extends AsyncTask<Void, Void, ArrayList> {

        private String nom , nJugadors ,temps,  categoria ,genere;

        public busquedaJuegos(String nom, String nJugadors, String temps, String categoria, String genere){
            this.nom = nom;
            this.nJugadors = nJugadors;
            this.temps = temps;
            this.categoria = categoria;
            this.genere = genere;
        }

        @Override
        protected ArrayList doInBackground(Void... voids) {

            Log.d("BUSQUEDA", "Realizando busqueda");
            DAOFactory daoFactory = DAOFactory.getDAOFactory(DAOFactory.MYSQL);
            JocDAO jocDAO = daoFactory.getJocDAO();
            ArrayList<Joc> juegosEncontrados = jocDAO.busquedaAvanzada(nom, nJugadors, temps, categoria, genere);
            Log.d("BUSQUEDA", "Busqueda finalizada");
            return juegosEncontrados;

        }
    }


}
