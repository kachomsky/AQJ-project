package nucli.com.aquejugamos.DAO;

import java.util.List;

import nucli.com.aquejugamos.general.JocTaula;

public interface JocTaulaDAO {
	
	public void carregarJocsTaula();
	public List<JocTaula> getLlistaJocsTaula();

}
