package com.example.mksh_pc.aqj;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import nucli.com.aquejugamos.DAO.DAOFactory;
import nucli.com.aquejugamos.DAO.JocDAO;
import nucli.com.aquejugamos.DAO.JocTaulaDAO;
import nucli.com.aquejugamos.general.Joc;
import nucli.com.aquejugamos.general.JocTaula;

public class JuegosFragment extends Fragment {
    public JuegosFragment(){}

    ArrayList<JocTaula> listaJuegos;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_juegos, container, false);
        Log.d("LISTA JUEGOS", "entrando dentro de la vista de juegos");
        Bundle bundle = this.getArguments();
        listaJuegos = new ArrayList<JocTaula>();
        ListView listView = (ListView) view.findViewById(R.id.listaJuegos);
        boolean misjuegosNoLogin = false;
        if (bundle != null) {
            if(bundle.getBoolean("misjuegos")){
                Log.d("PARTIDAS", "DENTRO DE MIS JUEGOS");
                SharedPreferences prefs = getActivity().getSharedPreferences("login", Context.MODE_PRIVATE);
                if (!prefs.getBoolean("isLogged", false)) {
                    misjuegosNoLogin = true;
                    Log.d("PARTIDAS", "NO logueado");
                    view = inflater.inflate(R.layout.msg_no_login, container, false);
                    view.findViewById(R.id.iniciarSesionBtn).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            Log.d("JUEGOSFRAGMENT", "Seleccionada opcion búsqueda");
                            startActivity(new Intent(getActivity(), Login.class));
                        }
                    });

                    view.findViewById(R.id.registrarseBtn).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            Log.d("JUEGOSFRAGMENT", "Seleccionada opcion búsqueda");
                            startActivity(new Intent(getActivity(), Registrarse.class));
                        }
                    });
                }else{
                    Log.d("JUEGOS", "DENTRO DEL BUNDLE");
                    listaJuegos = bundle.getParcelableArrayList("juegosEncontrados");
                    for(Joc j : listaJuegos){
                        Log.d("JUEGOS", j.getNomJoc());
                    }
                }
            }else{
                Log.d("JUEGOS", "DENTRO DEL BUNDLE");
                listaJuegos = bundle.getParcelableArrayList("juegosEncontrados");
                for(Joc j : listaJuegos){
                    Log.d("JUEGOS", j.getNomJoc());
                }
            }

        }else{
            Log.d("JUEGOS", "NO HA PASADO POR BUNDLE");
            ExecutorService executor = Executors.newCachedThreadPool();
            Future<ArrayList> juegosCargadosBD = executor.submit(new cargarJuegos());
            Log.d("LISTA JUEGOS", "juegos cargados");
            // Construct the data source
            try {
                Log.d("LISTA JUEGOS", "Recogiendo datos de base de datos");
                listaJuegos = juegosCargadosBD.get();
                Log.d("LISTA JUEGOS", "Datos BD cargados");
            } catch (Exception e) {
                System.out.print(e.getMessage());
            }
        }
        //if(!misjuegosNoLogin) {
            // Create the adapter to convert the array to views
            Log.d("LISTA JUEGOS", "preparando para crear adaptador de juegos");
            JuegosAdapter adapter = new JuegosAdapter(getActivity(), listaJuegos);
            Log.d("LISTA JUEGOS", "adaptador de juegos completado");
            // Attach the adapter to a ListView
            listView.setAdapter(adapter);

            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    Log.d("LISTA JUEGOS", "El tag del item clickado es" + view.findViewById(R.id.nombreJuego).getTag().toString());
                    parent.getItemAtPosition(position);
                    Intent intent = new Intent(view.getContext(), DetallesJuegos.class);
                    intent.putExtra("idJuego", (int) view.findViewById(R.id.nombreJuego).getTag());
                    //based on item add info to intent
                    startActivity(intent);
                }

            });
        //}
        return view;
    }

    public class cargarJuegos implements Callable<ArrayList> {
        @Override
        public ArrayList call() throws Exception {
            // Here your implementation
            //return new String("Result");
            DAOFactory mysqlFactory = DAOFactory.getDAOFactory(DAOFactory.MYSQL);
            JocDAO jocDAO = mysqlFactory.getJocDAO();
            ArrayList<Joc> jocs = jocDAO.carregarJocs();
            return jocs;
        }
    }

    public class cargarImagen implements Callable<Bitmap> {
        private Joc j;

        public cargarImagen(Joc j){
            this.j = j;
        }

        @Override
        public Bitmap call() throws Exception {
            Bitmap bmp = null;
            if(!this.j.getImagen().equals("")) {
                try {
                    Log.i("LISTA JUEGOS","La url del juego "+ j.getNomJoc() +" es:" + j.getImagen());
                    //URL url = new URL("https://www.gettyimages.es/gi-resources/images/Embed/new/embed2.jpg");
                    URL url = new URL(j.getImagen());
                    bmp = BitmapFactory.decodeStream(url.openConnection().getInputStream());
                    return bmp;
                } catch (IOException e) {
                    Log.e("LISTA JUEGOS", "URL del juego " + j.getNomJoc() + " no esta bien formada");
                    //throw new RuntimeException(e);
                }

            }
            return bmp;
        }
    }

    public class JuegosAdapter extends ArrayAdapter<JocTaula> {

        public JuegosAdapter(@NonNull Context context, ArrayList<JocTaula> listaJuegos) {
            super(context, 0, listaJuegos);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent){
            Joc joc = getItem(position);
            if (convertView == null) {
                convertView = LayoutInflater.from(getContext()).inflate(R.layout.fila_lista_juegos, parent, false);
            }

            TextView nombreJuego = (TextView) convertView.findViewById(R.id.nombreJuego);
            TextView valoracion = (TextView) convertView.findViewById(R.id.valoracionTVLJ);
            TextView nJugadores = (TextView) convertView.findViewById(R.id.nJugadoresTVLJ);
            nombreJuego.setText(joc.getNomJoc());
            valoracion.setText(joc.getValoracio());
            String numJugadoresFormat = joc.getNumeroJugadors();
            String[] parts = numJugadoresFormat.split("\\s+");

            if(parts.length >= 2){
                numJugadoresFormat = " " + parts[0] + " a " + parts[1];
            }else{
                numJugadoresFormat = " " + parts[0];
            }

            nJugadores.setText(numJugadoresFormat);
            ImageView imagenJuego = (ImageView) convertView.findViewById(R.id.juegoImagen);
            Log.d("LISTA JUEGOS", "Asociando tag a juego " + joc.getNomJoc() + ": id asociada =>" + joc.getIdJuego());
            nombreJuego.setTag(joc.getIdJuego());
            Log.d("LISTA JUEGOS", "El juego " + joc.getNomJoc() + " tiene asociado el tag " + nombreJuego.getTag());
            if(!joc.getImagen().equals(""))
                Picasso.with(convertView.getContext()).load(joc.getImagen()).into(imagenJuego);

            return convertView;
        }
    }

    /*@Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        Log.d("JUEGOS","Dentro de on activity created");
        if (savedInstanceState != null) {
            Log.d("JUEGOS","Bundle saveInstace Existente");
            // Restore last state for checked position.
            listaJuegos = savedInstanceState.getParcelableArrayList("juegosEncontrados");
        }
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        Log.d("JUEGOS","Dentro de on SAVE INSTANCE");
        outState.putParcelableArrayList("juegosEncontrados",listaJuegos);
        //Save the fragment's state here
    }*/


}

