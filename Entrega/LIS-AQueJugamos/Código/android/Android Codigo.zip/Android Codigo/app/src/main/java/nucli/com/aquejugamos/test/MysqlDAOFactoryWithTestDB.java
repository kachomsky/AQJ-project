package nucli.com.aquejugamos.test;

import java.sql.Connection;
import java.sql.SQLException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import nucli.com.aquejugamos.DAO.DAOFactory;
import nucli.com.aquejugamos.DAO.JocAlternatiuDAO;
import nucli.com.aquejugamos.DAO.JocDAO;
import nucli.com.aquejugamos.DAO.JocTaulaDAO;
import nucli.com.aquejugamos.DAO.MysqlDAOFactory;
import nucli.com.aquejugamos.DAO.PartidaDAO;
import nucli.com.aquejugamos.DAO.UsuarioDAO;
import nucli.com.aquejugamos.DAOImplementation.JocAlternatiuDAOMysqlImp;
import nucli.com.aquejugamos.DAOImplementation.JocDAOMysqlImp;
import nucli.com.aquejugamos.DAOImplementation.JocTaulaDAOMysqlImp;
import nucli.com.aquejugamos.DAOImplementation.PartidaDAOMysqlImp;
import nucli.com.aquejugamos.DAOImplementation.UsuarioDAOMysqlImp;
import com.mysql.jdbc.jdbc2.optional.MysqlDataSource;

public class MysqlDAOFactoryWithTestDB extends DAOFactory{
	/** Logger **/
	private static Logger logger = LoggerFactory.getLogger(MysqlDAOFactoryWithTestDB.class);		
	
	
	public MysqlDAOFactoryWithTestDB() {};
	
	/** Usaremos este metodo cada vez que queramos una conexion de tipo mysql **/
	
	public static Connection crearConexio() {
		Connection conn = null;
		MysqlDataSource dataSource;
		dataSource = new MysqlDataSource();
		dataSource.setUser("root");
		dataSource.setServerName("127.0.0.1");
		dataSource.setPassword("");
		dataSource.setDatabaseName("aquejugamostest"); //cambiamos a una base de datos local de pruebas, una copia de la original, para no ocasionar efectos secundarios en la base de datos original
		
		try {
			conn = dataSource.getConnection();
		} catch (SQLException e) {			
			e.printStackTrace();
		}		
		
		return conn;
		
	}

	
	@Override
    public JocAlternatiuDAO getJocAlternatiuDAO() {
        return new JocAlternatiuDAOMysqlImp(DAOFactory.MYSQLTEST);
    }
 
	@Override
    public JocTaulaDAO getJocTaulaDAO() {
        return new JocTaulaDAOMysqlImp(DAOFactory.MYSQLTEST);
    }
	
	@Override
    public JocDAO getJocDAO() {
        return new JocDAOMysqlImp(DAOFactory.MYSQLTEST);
    }
	
	@Override
    public PartidaDAO getPartidaDAO() {
        return new PartidaDAOMysqlImp(DAOFactory.MYSQLTEST);
    }
	
	@Override
    public UsuarioDAO getUsuarioDAO() {
        return new UsuarioDAOMysqlImp(DAOFactory.MYSQLTEST);
    }

}
