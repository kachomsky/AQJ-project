package nucli.com.aquejugamos.DAO;

import java.sql.Connection;
import java.sql.SQLException;

import nucli.com.aquejugamos.test.MysqlDAOFactoryWithTestDB;

public abstract class DAOFactory {

	/** numero para identificar que queremos usar una conexion Mysql **/
	public static final int MYSQL = 0;
	/** numero para identificar que queremos usar una conexion Mysql aislada para el test **/
	public static final int MYSQLTEST = 1;
	
	/** Abstract method para el JocAlternatiuDAO. */
    public abstract JocAlternatiuDAO getJocAlternatiuDAO();
    /** Abstract method para el JocDAO. */
    public abstract JocDAO getJocDAO();
    /** Abstract method para el JocTaulaDAO. */
    public abstract JocTaulaDAO getJocTaulaDAO();
    /** Abstract method para el PartidaDAO. */
    public abstract PartidaDAO getPartidaDAO();
    /** Abstract method para el UsuarioDAO. */
    public abstract UsuarioDAO getUsuarioDAO();
   
    

	
	/** Aqui podremos añadir tantas bases de datos diferentes como queramos, 
	 *  desde el main solo haria falta cambiar el numero de la base de datos a 
	 *  utilizar y adaptariamos todo**
	 **/
	
	public static DAOFactory getDAOFactory(int databaseType) {
		
		DAOFactory daofactory;
		
		switch(databaseType) {
			case MYSQL:				
				daofactory = new MysqlDAOFactory();				
			break;
			case MYSQLTEST:
				daofactory = new MysqlDAOFactoryWithTestDB();
			break;
		default:
				daofactory = null;
			break;
		}			
		return daofactory;
	}
	
	
}
