package nucli.com.aquejugamos.test;
import static org.junit.Assert.*;

import org.junit.Test;

import nucli.com.aquejugamos.DAO.DAOFactory;
import nucli.com.aquejugamos.DAO.PartidaDAO;

public class PartidaDAOMysqlImpTest {

	DAOFactory mysqlFactory = DAOFactory.getDAOFactory(DAOFactory.MYSQLTEST);
	PartidaDAO partidaDAO = mysqlFactory.getPartidaDAO();
	
	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
