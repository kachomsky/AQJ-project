package nucli.com.aquejugamos.test;

import static org.junit.Assert.*;

import org.junit.Test;

import nucli.com.aquejugamos.DAO.DAOFactory;
import nucli.com.aquejugamos.DAO.UsuarioDAO;
import nucli.com.aquejugamos.general.Usuari;
import nucli.com.aquejugamos.general.Joc;
import java.util.ArrayList;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;


@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class UsuarioDAOMysqlImpTest {

	DAOFactory mysqlFactory = DAOFactory.getDAOFactory(DAOFactory.MYSQLTEST);
	UsuarioDAO usuarioDAO = mysqlFactory.getUsuarioDAO();


	@Before
	public void setUp() throws Exception
	{
		usuarioDAO.carregarUsuaris();
	}

	@Test
	public void A_insertarUsuariTest() {

		System.out.println("insertando");
		Usuari u = new Usuari(0, "test","test","test@gmail.com",1,0,1,"test","12-02-2018","Barcelona", "test1");
		assertTrue(usuarioDAO.insertarUsuari(u));

		u = new Usuari(0, "manuel", "manuel123", "maindeprueba@gmail.com", 1, 0, 0, "UAB", "12-04-2001", "Madrid", "test2");
		assertTrue(usuarioDAO.insertarUsuari(u));


		/*//Caso de prueba para comprobar que el nombre no esta vacio
		u = new Usuari(0, "", "manuel123", "maindeprueba1@gmail.com", 1, 0, 0, "UAB", "12-04-2001", "Madrid", "nick1");
		assertFalse(usuarioDAO.insertarUsuari(u));

		//Caso de prueba para comprobar que la password no esta vacia
		u = new Usuari(0, "manuel", "", "maindeprueba2@gmail.com", 1, 0, 0, "UAB", "12-04-2001", "Madrid", "nick2");
		assertFalse(usuarioDAO.insertarUsuari(u));

		//Caso de prueba para comprobar que el email no esta vacio
		u = new Usuari(0, "manuel", "manuel123", "", 1, 0, 0, "UAB", "12-04-2001", "Madrid", "nick3");
		assertFalse(usuarioDAO.insertarUsuari(u));

		//Caso de prueba para comprobar que el grupo no esta vacio
		u = new Usuari(0, "manuel", "manuel123", "maindeprueba3@gmail.com", 1, 0, 0, "", "12-04-2001", "Madrid", "nick4");
		assertFalse(usuarioDAO.insertarUsuari(u));

		//Caso de prueba para comprobar que la fecha no esta vacia
		u = new Usuari(0, "manuel", "manuel123", "maindeprueba4@gmail.com", 1, 0, 0, "UAB", "", "Madrid", "nick5");
		assertFalse(usuarioDAO.insertarUsuari(u));

		//Caso de prueba para comprobar que la fecha tiene el formato correcto
		u = new Usuari(0, "manuel", "manuel123", "maindeprueba5@gmail.com", 1, 0, 0, "UAB", "fechaaa", "", "nick6");
		assertFalse(usuarioDAO.insertarUsuari(u));

		//Caso de prueba para comprobar que el correo tiene el formato correcto
		u = new Usuari(0, "manuel", "manuel123", "emaail3", 1, 0, 0, "UAB", "fechaaa", "Madrid", "nick7");
		assertFalse(usuarioDAO.insertarUsuari(u));

		//Caso de prueba para comprobar que la fecha de nacimiento no es futura
		u = new Usuari(0, "manuel", "manuel123", "emaail4", 1, 0, 0, "UAB", "12-04-2020", "Madrid", "nick8");
		assertFalse(usuarioDAO.insertarUsuari(u));*/
	}


	@Test
	public void B_carregarUsuarisTest() {
		ArrayList<Usuari>  usuarisCorrectes = new ArrayList<Usuari>();
		Usuari u1 = new Usuari(0, "test","test","test@gmail.com",1,0,1,"test","12-02-2018","Barcelona", "test1");
		Usuari u2 = new Usuari(0, "manuel", "manuel123", "maindeprueba@gmail.com", 1, 0, 0, "UAB", "12-04-2001", "Madrid", "test2");
		usuarisCorrectes.add(u1);
		usuarisCorrectes.add(u2);

		int i = 0;
		for(Usuari u : usuarioDAO.getLlistaUsuaris()) {
			assertEquals(u.getMail(), usuarisCorrectes.get(i).getMail());
			assertEquals(u.getNomUsuari(), usuarisCorrectes.get(i).getNomUsuari());
			assertEquals(u.getPassword(), usuarisCorrectes.get(i).getPassword());
			assertEquals(u.getActivo(), usuarisCorrectes.get(i).getActivo());
			assertEquals(u.getBloqueado(), usuarisCorrectes.get(i).getBloqueado());
			assertEquals(u.getIsAdmin(), usuarisCorrectes.get(i).getIsAdmin());
			assertEquals(u.getGrupo(), usuarisCorrectes.get(i).getGrupo());
			assertEquals(u.getFecha(), usuarisCorrectes.get(i).getFecha());
			assertEquals(u.getProvincia(), usuarisCorrectes.get(i).getProvincia());
			i++;
		}
	}

	@Test
	public void C_afegirLlistaPreferitsTest() {

		//Miramos para los datos que hay en la BD , que se inserte correctamente

		for(Usuari u : usuarioDAO.getLlistaUsuaris()) {
			assertTrue(usuarioDAO.afegirLlistaPreferits(1, u.getIdUsuari()));
			assertTrue(usuarioDAO.afegirLlistaPreferits(2, u.getIdUsuari()));
		}

		//Si se pasan id de usuario que no existe en la BD
		assertFalse(usuarioDAO.afegirLlistaPreferits(58, 999));

		//Si pasamos la id de un juego que no existe
		assertFalse(usuarioDAO.afegirLlistaPreferits(usuarioDAO.getLlistaUsuaris().get(0).getIdUsuari(), 999));

		//Si no pasamos ninguna de las ids existentes
		assertFalse(usuarioDAO.afegirLlistaPreferits(999, 999));

	}

	@Test
	public void D_carregarLlistaFavoritsUserTest() {
		//TODO
		System.out.println("dentro de carregar");
		System.out.println(usuarioDAO.getLlistaUsuaris().get(0).getNomUsuari());
		System.out.println(usuarioDAO.getLlistaUsuaris().get(1).getNomUsuari());
		Joc j1 = new Joc(1, 1, "categoria", "Catan", 1, 18,
				"3-4", "30min", "tipo", "catan", "0", 1,
				"imagen");

		Joc j2 = new Joc(2, 2, "categoria", "Tres en raya", 0, 3,
				"2", "1min", "tipo", "raya", "100", 1,
				"imagen");

		ArrayList<Joc> listaCorrectaJuegos = new ArrayList<Joc>();

		listaCorrectaJuegos.add(j1);
		listaCorrectaJuegos.add(j2);

		assertEquals(usuarioDAO.getLlistaUsuaris().get(0).getLlistaJocs().get(0).getIdJuego(), listaCorrectaJuegos.get(0).getIdJuego());
		assertEquals(usuarioDAO.getLlistaUsuaris().get(0).getLlistaJocs().get(0).getIdCategoria(), listaCorrectaJuegos.get(0).getIdCategoria());
		assertEquals(usuarioDAO.getLlistaUsuaris().get(0).getLlistaJocs().get(0).getNomCategoria(), listaCorrectaJuegos.get(0).getNomCategoria());
		assertEquals(usuarioDAO.getLlistaUsuaris().get(0).getLlistaJocs().get(0).getNomJoc(), listaCorrectaJuegos.get(0).getNomJoc());
		assertEquals(usuarioDAO.getLlistaUsuaris().get(0).getLlistaJocs().get(0).getDificultat(), listaCorrectaJuegos.get(0).getDificultat());
		assertEquals(usuarioDAO.getLlistaUsuaris().get(0).getLlistaJocs().get(0).getEdat(), listaCorrectaJuegos.get(0).getEdat());
		assertEquals(usuarioDAO.getLlistaUsuaris().get(0).getLlistaJocs().get(0).getNumeroJugadors(), listaCorrectaJuegos.get(0).getNumeroJugadors());
		assertEquals(usuarioDAO.getLlistaUsuaris().get(0).getLlistaJocs().get(0).getDescripcio(), listaCorrectaJuegos.get(0).getDescripcio());
		assertEquals(usuarioDAO.getLlistaUsuaris().get(0).getLlistaJocs().get(0).getDuracio(), listaCorrectaJuegos.get(0).getDuracio());
		assertEquals(usuarioDAO.getLlistaUsuaris().get(0).getLlistaJocs().get(0).getValoracio(), listaCorrectaJuegos.get(0).getValoracio());
		assertEquals(usuarioDAO.getLlistaUsuaris().get(0).getLlistaJocs().get(0).getIdTipo(), listaCorrectaJuegos.get(0).getIdTipo());

		assertEquals(usuarioDAO.getLlistaUsuaris().get(0).getLlistaJocs().get(1).getIdJuego(), listaCorrectaJuegos.get(1).getIdJuego());
		assertEquals(usuarioDAO.getLlistaUsuaris().get(0).getLlistaJocs().get(1).getIdCategoria(), listaCorrectaJuegos.get(1).getIdCategoria());
		assertEquals(usuarioDAO.getLlistaUsuaris().get(0).getLlistaJocs().get(1).getNomCategoria(), listaCorrectaJuegos.get(1).getNomCategoria());
		assertEquals(usuarioDAO.getLlistaUsuaris().get(0).getLlistaJocs().get(1).getNomJoc(), listaCorrectaJuegos.get(1).getNomJoc());
		assertEquals(usuarioDAO.getLlistaUsuaris().get(0).getLlistaJocs().get(1).getDificultat(), listaCorrectaJuegos.get(1).getDificultat());
		assertEquals(usuarioDAO.getLlistaUsuaris().get(0).getLlistaJocs().get(1).getEdat(), listaCorrectaJuegos.get(1).getEdat());
		assertEquals(usuarioDAO.getLlistaUsuaris().get(0).getLlistaJocs().get(1).getNumeroJugadors(), listaCorrectaJuegos.get(1).getNumeroJugadors());
		assertEquals(usuarioDAO.getLlistaUsuaris().get(0).getLlistaJocs().get(1).getDescripcio(), listaCorrectaJuegos.get(1).getDescripcio());
		assertEquals(usuarioDAO.getLlistaUsuaris().get(0).getLlistaJocs().get(1).getDuracio(), listaCorrectaJuegos.get(1).getDuracio());
		assertEquals(usuarioDAO.getLlistaUsuaris().get(0).getLlistaJocs().get(1).getValoracio(), listaCorrectaJuegos.get(1).getValoracio());
		assertEquals(usuarioDAO.getLlistaUsuaris().get(0).getLlistaJocs().get(1).getIdTipo(), listaCorrectaJuegos.get(1).getIdTipo());

		assertEquals(usuarioDAO.getLlistaUsuaris().get(1).getLlistaJocs().get(0).getIdJuego(), listaCorrectaJuegos.get(0).getIdJuego());
		assertEquals(usuarioDAO.getLlistaUsuaris().get(1).getLlistaJocs().get(0).getIdCategoria(), listaCorrectaJuegos.get(0).getIdCategoria());
		assertEquals(usuarioDAO.getLlistaUsuaris().get(1).getLlistaJocs().get(0).getNomCategoria(), listaCorrectaJuegos.get(0).getNomCategoria());
		assertEquals(usuarioDAO.getLlistaUsuaris().get(1).getLlistaJocs().get(0).getNomJoc(), listaCorrectaJuegos.get(0).getNomJoc());
		assertEquals(usuarioDAO.getLlistaUsuaris().get(1).getLlistaJocs().get(0).getDificultat(), listaCorrectaJuegos.get(0).getDificultat());
		assertEquals(usuarioDAO.getLlistaUsuaris().get(1).getLlistaJocs().get(0).getEdat(), listaCorrectaJuegos.get(0).getEdat());
		assertEquals(usuarioDAO.getLlistaUsuaris().get(1).getLlistaJocs().get(0).getNumeroJugadors(), listaCorrectaJuegos.get(0).getNumeroJugadors());
		assertEquals(usuarioDAO.getLlistaUsuaris().get(1).getLlistaJocs().get(0).getDescripcio(), listaCorrectaJuegos.get(0).getDescripcio());
		assertEquals(usuarioDAO.getLlistaUsuaris().get(1).getLlistaJocs().get(0).getDuracio(), listaCorrectaJuegos.get(0).getDuracio());
		assertEquals(usuarioDAO.getLlistaUsuaris().get(1).getLlistaJocs().get(0).getValoracio(), listaCorrectaJuegos.get(0).getValoracio());
		assertEquals(usuarioDAO.getLlistaUsuaris().get(1).getLlistaJocs().get(0).getIdTipo(), listaCorrectaJuegos.get(0).getIdTipo());

		assertEquals(usuarioDAO.getLlistaUsuaris().get(1).getLlistaJocs().get(1).getIdJuego(), listaCorrectaJuegos.get(1).getIdJuego());
		assertEquals(usuarioDAO.getLlistaUsuaris().get(1).getLlistaJocs().get(1).getIdCategoria(), listaCorrectaJuegos.get(1).getIdCategoria());
		assertEquals(usuarioDAO.getLlistaUsuaris().get(1).getLlistaJocs().get(1).getNomCategoria(), listaCorrectaJuegos.get(1).getNomCategoria());
		assertEquals(usuarioDAO.getLlistaUsuaris().get(1).getLlistaJocs().get(1).getNomJoc(), listaCorrectaJuegos.get(1).getNomJoc());
		assertEquals(usuarioDAO.getLlistaUsuaris().get(1).getLlistaJocs().get(1).getDificultat(), listaCorrectaJuegos.get(1).getDificultat());
		assertEquals(usuarioDAO.getLlistaUsuaris().get(1).getLlistaJocs().get(1).getEdat(), listaCorrectaJuegos.get(1).getEdat());
		assertEquals(usuarioDAO.getLlistaUsuaris().get(1).getLlistaJocs().get(1).getNumeroJugadors(), listaCorrectaJuegos.get(1).getNumeroJugadors());
		assertEquals(usuarioDAO.getLlistaUsuaris().get(1).getLlistaJocs().get(1).getDescripcio(), listaCorrectaJuegos.get(1).getDescripcio());
		assertEquals(usuarioDAO.getLlistaUsuaris().get(1).getLlistaJocs().get(1).getDuracio(), listaCorrectaJuegos.get(1).getDuracio());
		assertEquals(usuarioDAO.getLlistaUsuaris().get(1).getLlistaJocs().get(1).getValoracio(), listaCorrectaJuegos.get(1).getValoracio());
		assertEquals(usuarioDAO.getLlistaUsuaris().get(1).getLlistaJocs().get(1).getIdTipo(), listaCorrectaJuegos.get(1).getIdTipo());
	}

	@Test
	public void E_comprobarUsuariTest() {
		//TODO
		assertTrue(usuarioDAO.comprobarUsuari("test@gmail.com", "test"));
		//Email y contrasena mal
		assertFalse(usuarioDAO.comprobarUsuari("test22@gmail.com", "test22"));
		//Solo Email mal
		assertFalse(usuarioDAO.comprobarUsuari("test22@gmail.com", "test"));
		//Solo contrasena mal
		assertFalse(usuarioDAO.comprobarUsuari("test@gmail.com", "test22"));
		//Email y contrasena cambiados de orden
		assertFalse(usuarioDAO.comprobarUsuari("test", "test@gmail.com"));
	}

	@Test
	public void F_comprovarUsuariLogejatTest() {
		//TODO
		assertFalse(usuarioDAO.comprovarUsuariLogejat());
		usuarioDAO.comprobarUsuari("test@gmail.com", "test");
		assertTrue(usuarioDAO.comprovarUsuariLogejat());
	}

	@Test
	public void G_logoutTest() {
		//TODO
		//assertTrue(usuarioDAO.logout());
		assertFalse(usuarioDAO.logout());
	}



	@Test
	public void H_eliminarUsuarioTest() {
		//TODO
		assertTrue(usuarioDAO.eliminarUsuario("test@gmail.com"));
		assertTrue(usuarioDAO.eliminarUsuario("maindeprueba@gmail.com"));
		assertFalse(usuarioDAO.eliminarUsuario("estegmailnoexiste@gmail.com"));
	}




}
