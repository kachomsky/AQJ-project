package nucli.com.aquejugamos.test;

import static org.junit.Assert.*;

import java.util.ArrayList;
import org.junit.Test;
import nucli.com.aquejugamos.DAO.DAOFactory;
import nucli.com.aquejugamos.DAO.JocTaulaDAO;
import nucli.com.aquejugamos.general.Joc;
import nucli.com.aquejugamos.general.JocTaula;

public class JocTaulaDAOMysqlImpTest {

	DAOFactory mysqlFactory = DAOFactory.getDAOFactory(DAOFactory.MYSQLTEST);
	JocTaulaDAO jocTaulaDAO = mysqlFactory.getJocTaulaDAO();
	
	@Test
	public void carregarJocsTaulaTest() {
		jocTaulaDAO.carregarJocsTaula();
		ArrayList<JocTaula> jocsTaulaCorrectes = new ArrayList<JocTaula>();
		
		JocTaula j1 = new JocTaula(0,1,"Mesa", "Catan", 1, 18,
				"3-4", "30min", "tipo", "catan", "0", 1,
				 "https://aquejugamos.000webhostapp.com/catan.jpg");
		JocTaula j2 = new JocTaula(0,1,"Alternativo", "Tres en raya", 0, 3,
				"2", "1min", "tipo", "raya", "100", 1,
				 "");
		jocsTaulaCorrectes.add(j1);		
		
		assertEquals(jocTaulaDAO.getLlistaJocsTaula().get(0).getDescripcio(),jocsTaulaCorrectes.get(0).getDescripcio());
		assertEquals(jocTaulaDAO.getLlistaJocsTaula().get(0).getDificultat(), jocsTaulaCorrectes.get(0).getDificultat());
		assertEquals(jocTaulaDAO.getLlistaJocsTaula().get(0).getDuracio(), jocsTaulaCorrectes.get(0).getDuracio());
		assertEquals(jocTaulaDAO.getLlistaJocsTaula().get(0).getEdat(), jocsTaulaCorrectes.get(0).getEdat());
		assertEquals(jocTaulaDAO.getLlistaJocsTaula().get(0).getIdCategoria(), jocsTaulaCorrectes.get(0).getIdCategoria());		
		assertEquals(jocTaulaDAO.getLlistaJocsTaula().get(0).getIdTipo(), jocsTaulaCorrectes.get(0).getIdTipo());
		assertEquals(jocTaulaDAO.getLlistaJocsTaula().get(0).getImagen(), jocsTaulaCorrectes.get(0).getImagen());
		assertEquals(jocTaulaDAO.getLlistaJocsTaula().get(0).getNomCategoria(), jocsTaulaCorrectes.get(0).getNomCategoria());
		assertEquals(jocTaulaDAO.getLlistaJocsTaula().get(0).getNomJoc(), jocsTaulaCorrectes.get(0).getNomJoc());
		assertEquals(jocTaulaDAO.getLlistaJocsTaula().get(0).getNumeroJugadors(), jocsTaulaCorrectes.get(0).getNumeroJugadors());
		assertEquals(jocTaulaDAO.getLlistaJocsTaula().get(0).getIdTipo(), jocsTaulaCorrectes.get(0).getIdTipo());
		assertEquals(jocTaulaDAO.getLlistaJocsTaula().get(0).getValoracio(), jocsTaulaCorrectes.get(0).getValoracio());
		
		
				
	}

}
