package nucli.com.aquejugamos.DAO;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import nucli.com.aquejugamos.general.Joc;
import nucli.com.aquejugamos.general.Usuari;

public interface UsuarioDAO {

	public void carregarUsuaris();

	public boolean comprobarUsuari(String mail, String password);

	public boolean afegirLlistaPreferits(int idJoc, int idUsuari);

	public void consultaDadesUsuari();

	public boolean insertarUsuari(Usuari u);

	public boolean comprovarUsuariLogejat();

	public void carregarAmicsUsuari() throws SQLException;

	public boolean agregarAmic(int idUsuariLogejat, int idUsuariAgregar);

	public boolean logout();

	public List<Usuari> getLlistaUsuaris();

	public List<Integer> getLlistaIdUsuaris();

	public boolean eliminarUsuario(String email);

	public Usuari buscarUsuarioPorId(int idUser);

	public Usuari buscarUsuarioPorNickname(String nickname);

	public Usuari loginUsuari(String email, String password);

	public Map validarRegistro(Usuari u);

	public ArrayList<Joc> carregarLlistaFavoritsUser(Usuari u) throws SQLException;
}