package com.example.mksh_pc.aqj;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.NavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.app.FragmentManager;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.util.ArrayList;

import nucli.com.aquejugamos.DAO.DAOFactory;
import nucli.com.aquejugamos.DAO.UsuarioDAO;
import nucli.com.aquejugamos.general.Joc;
import nucli.com.aquejugamos.general.Main;
import nucli.com.aquejugamos.general.Usuari;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = MainActivity.class.getSimpleName();
    private BottomNavigationView bottomNavigationView;
    private FloatingActionButton fabBusqueda;
    private FloatingActionButton fabPartida;
    private Fragment fragment;
    private FragmentManager fragmentManager;
    private Menu menu;
    private Usuari userLogeado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        SharedPreferences prefs = getSharedPreferences("login", Context.MODE_PRIVATE);
        /*editor.putInt("activo", usuarioLogueado.getActivo());
                editor.putInt("bloqueado", usuarioLogueado.getBloqueado());
                editor.putInt("admin", usuarioLogueado.getIsAdmin());
                editor.putString("grupo", usuarioLogueado.getGrupo());
                editor.putString("fecha", usuarioLogueado.getFecha());
                editor.putString("provincia", usuarioLogueado.getProvincia());
                editor.putString("nickname", usuarioLogueado.getNickname());*/
        int idUsuario = prefs.getInt("id",0);
        String nomUsuario = prefs.getString("nombre","");
        String password = prefs.getString("password","");
        String email = prefs.getString("email","");
        int activo = prefs.getInt("activo",0);
        int bloqueado = prefs.getInt("bloqueado",0);
        int admin = prefs.getInt("admin",0);
        String grupo = prefs.getString("grupo","");
        String fecha = prefs.getString("fecha","");
        String provincia = prefs.getString("provincia","");
        String nickname = prefs.getString("nickname","");
        userLogeado = new Usuari(idUsuario, nomUsuario, password, email,activo,bloqueado,admin,grupo,fecha,provincia,nickname);
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.activity_main);
        //drawer.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_OPEN);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView mNavigationView = (NavigationView) findViewById(R.id.nav_view);
        View header = mNavigationView.getHeaderView(0);

        /*Button login = (Button) header.findViewById(R.id.iniciarSesionNHM);
        SharedPreferences prefs = getSharedPreferences("login", Context.MODE_PRIVATE);
        if (prefs.getBoolean("isLogged", false)) {
            Log.d("MAIN", "Existe una sesión");
            Log.d("MAIN", "Ocultando botón de registro");
            registro.setVisibility(View.INVISIBLE);
            login.setText("Logout");
        } else {
            Log.d("MAIN", "No existe una sesión");
        }*/

        final Context context = this;
        mNavigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                Intent intent = null;
                switch (item.getItemId()) {
                    case R.id.nav_perfil:
                        break;

                    case R.id.nav_mis_amigos:
                        break;

                    case R.id.nav_notificaciones:
                        break;

                    case R.id.nav_lista_deseos:
                        break;

                    case R.id.nav_configuracion:
                        break;

                    case R.id.registrarseNHM:
                        Log.d("MAIN", "Seleccionada opcion registrarse");
                        intent = new Intent(context, Registrarse.class);
                        startActivity(intent);
                        break;

                    case R.id.iniciarSesionNHM:
                        Log.d("MAIN", "Seleccionada opcion de iniciar sesión");
                        intent = new Intent(context, Login.class);
                        startActivity(intent);
                        break;

                    case R.id.nav_cerrar_sesion:
                        Log.d("MAIN", "Seleccionada opcion de iniciar sesión");
                        intent = new Intent(context, Login.class);
                        startActivity(intent);
                        break;
                }

                DrawerLayout drawer = (DrawerLayout) findViewById(R.id.activity_main);
                drawer.closeDrawer(GravityCompat.START);
                return true;
            }
        });

        fabBusqueda = (FloatingActionButton) findViewById(R.id.fabBusqueda);
        fabBusqueda.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d("MAIN", "Seleccionada opcion búsqueda");
                startActivity(new Intent(MainActivity.this, BusquedaActivity.class));
            }
        });

        fabPartida = (FloatingActionButton) findViewById(R.id.fabPartida);
        fabPartida.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d("MAIN", "Seleccionada opcion búsqueda");
                startActivity(new Intent(MainActivity.this,CrearPartidaActivity.class));
            }
        });

        fabBusqueda.show();
        fabPartida.hide();

        bottomNavigationView = (BottomNavigationView) findViewById(R.id.navigation);
        fragment = new HomeFragment();
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.container_main, fragment).commit();

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                fragment = null;
                switch (item.getItemId()) {
                    case R.id.navigation_home:
                        fragment = HomeFragment.newInstance();
                        fabBusqueda.show();
                        fabPartida.hide();
                        break;
                    case R.id.navigation_lista_juegos:
                        fabBusqueda.show();
                        fabPartida.hide();
                        if (getIntent() != null && getIntent().hasExtra("opcion")) {
                            if (getIntent().getStringExtra("opcion").equals("listaJuegos")) {
                                Log.d("MAIN", "EXISTE UN INTENT CON OPCION: " + getIntent().getStringExtra("opcion"));
                                FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                                Bundle bundle = new Bundle();
                                bundle.putParcelableArrayList("juegosEncontrados", getIntent().getParcelableArrayListExtra("juegosEncontrados"));
                                fragment = new JuegosFragment();
                                fragment.setArguments(bundle);
                                transaction.replace(R.id.container_main, fragment).commit();
                            }
                        } else {
                            Log.d("MAIN", "NO EXISTE INTENT");
                            Log.d("MAIN", "seleccionada opcion lista juegos");
                            fragment = new JuegosFragment();
                        }

                        break;
                    case R.id.navigation_mis_juegos:
                        //fragment = new JuegosFragment();
                        /*SharedPreferences prefs = getSharedPreferences("login", Context.MODE_PRIVATE);
                        if (!prefs.getBoolean("isLogged", false)) {

                        }*/
                        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                        ArrayList<Joc> jocs = new ArrayList<>();
                        try{
                            jocs = new recogerSalon().execute().get();
                        }catch (Exception e){
                            Log.e("MAIN", e.getMessage());
                        }

                        Bundle bundle = new Bundle();
                        bundle.putParcelableArrayList("juegosEncontrados", jocs);
                        bundle.putBoolean("misjuegos",true);
                        fragment = new JuegosFragment();
                        fragment.setArguments(bundle);
                        transaction.replace(R.id.container_main, fragment).commit();
                        fabBusqueda.hide();
                        fabPartida.hide();
                        break;
                    case R.id.navigation_mis_partidas:
                        SharedPreferences prefs = getSharedPreferences("login", Context.MODE_PRIVATE);
                        if (!prefs.getBoolean("isLogged", false)) {
                            fabPartida.hide();
                        }else{
                            fabPartida.show();
                        }

                        fragment = new MisPartidasFragment();
                        fabBusqueda.hide();


                        break;
                }

                FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.container_main, fragment);
                transaction.commit();

                return true;
            }
        });
    }


    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        //opcion = 1;
        Log.d("MAIN", "DENTRO DE ON NEW INTENT");
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d("MAIN", "En ONSTART functino");
        if (getIntent() != null && getIntent().hasExtra("opcion")) {
            Log.d("MAIN", "Opcion enviada:" + getIntent().getStringExtra("opcion"));
            if (getIntent().getStringExtra("opcion").equals("listaJuegos")) {
                /*FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                Bundle bundle = new Bundle();
                bundle.putParcelableArrayList("juegosEncontrados", getIntent().getParcelableArrayListExtra("juegosEncontrados"));
                fragment = new JuegosFragment();
                fragment.setArguments(bundle);


                transaction.replace(R.id.container_main, fragment).commit();*/

                bottomNavigationView.setSelectedItemId(R.id.navigation_lista_juegos);
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d("MAIN", "DENTRO DE ONRESUME");
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.activity_main);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        getMenuInflater().inflate(R.menu.menu_lateral, menu);
        MenuItem registro = menu.findItem(R.id.registrarseNHM);
        MenuItem login =  menu.findItem(R.id.iniciarSesionNHM);
        SharedPreferences prefs = getSharedPreferences("login", Context.MODE_PRIVATE);
        if (prefs.getBoolean("isLogged", false)) {
            Log.d("MAIN", "Existe una sesión");
            Log.d("MAIN", "Ocultando botón de registro");
            registro.setVisible(false);
            login.setVisible(false);
        } else {
            Log.d("MAIN", "No existe una sesión");
        }
        return true;

    }

    private class recogerSalon extends AsyncTask<Void, Void, ArrayList<Joc>> {


        @Override
        protected ArrayList doInBackground(Void... voids) {
            ArrayList<Joc> jocs = new ArrayList<>();
            Log.d("MAIN", "Recogeiendo juegos del salon");
            DAOFactory daoFactory = DAOFactory.getDAOFactory(DAOFactory.MYSQL);
            UsuarioDAO usuarioDAO = daoFactory.getUsuarioDAO();
            try{
                jocs = usuarioDAO.carregarLlistaFavoritsUser(userLogeado);
            }catch (Exception e){
                Log.e("MAIN", e.getMessage());
            }

            Log.d("DETALLES", "Datos recogidos");

            return jocs;
        }
    }

}