package nucli.com.aquejugamos.DAOImplementation;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import nucli.com.aquejugamos.DAO.MysqlDAOFactory;
import nucli.com.aquejugamos.general.Usuari;
import nucli.com.aquejugamos.general.Partida;
import nucli.com.aquejugamos.DAO.PartidaDAO;
import nucli.com.aquejugamos.test.MysqlDAOFactoryWithTestDB;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;
import java.util.Scanner;

public class PartidaDAOMysqlImp implements PartidaDAO{

	/** Logger **/
	private static Logger logger = LoggerFactory.getLogger(PartidaDAOMysqlImp.class);
	private int databaseTest;
	public PartidaDAOMysqlImp() {};

	/** Constructor que se usara si queremos usar la base de datos de test **/
	public PartidaDAOMysqlImp(int databaseTest) {
		this.databaseTest = databaseTest;
	};


	public boolean etiquetarUsuario(Usuari u, Partida p, int puntos) {
		//TODO: buscar usuarios y anadirlos a la lista de usuarios de partida, y en la BD, en la tabla PartidasUsuario
		Connection conn = null;
		boolean correcto = false;
		int affectedRows = 0;

		if(databaseTest == 1) {
			conn = MysqlDAOFactoryWithTestDB.crearConexio();
		}else {
			conn = MysqlDAOFactory.crearConexio();
		}

		int partidaGanada = 0;

		if(u.getNickname().equals(p.getGanador())){
			partidaGanada = 1;
		}

		PreparedStatement pstmt;
		try {
			pstmt = conn.prepareStatement("INSERT INTO partidasusuario (idUsuario,idPartida, puntos, partida_ganada) VALUES (?,?,?,?)");
			logger.info("El id del usuario es: " + u.getIdUsuari());
			logger.info("El id de la partida es: " + p.getIdPartida());
			pstmt.setInt(1,u.getIdUsuari());
			pstmt.setInt(2,p.getIdPartida());
			pstmt.setInt(3,puntos);
			pstmt.setInt(4,partidaGanada);
			affectedRows = pstmt.executeUpdate();
			pstmt.close();

			if(affectedRows == 0) {
				logger.error("No se ha modificado ninguna fila al insertar. Fallido.");
				logger.error("Ha surgido un error al intentar insertar la partida: \n "
						+ "**Partida**\n" + p.getJuego()+"\n"+p.getFecha()+"\n"+p.getGanador()
						+"\n"+p.getNumJugadores()+"\n"+p.getComentarios()+"\n");
				//throw new SQLException("El registro del usuario ha fallado");
			}else {
				correcto = true;
				logger.info("Partida insertada correctamente: \n "
						+ "**Partida**\n" + p.getJuego()+"\n"+p.getFecha()+"\n"+p.getGanador()
						+"\n"+p.getNumJugadores()+"\n"+p.getComentarios()+"\n");
			}
		} catch (SQLException e) {
			logger.error("No se ha podido etiquetar usuario " + e.getMessage());
		}

		return correcto;

	}

	public boolean pujarPartida(Partida p, ArrayList<Integer> puntuaciones)
	{
		Connection conn = null;
		boolean correcto = false;
		int affectedRows = 0;
		String comentario = "";

		Date date = new Date();
		String hora = new SimpleDateFormat("HH:mm:ss").format(date);
		logger.debug("La hora recogida es:" + hora);
		if(databaseTest == 1) {
			conn = MysqlDAOFactoryWithTestDB.crearConexio();
		}else {
			conn = MysqlDAOFactory.crearConexio();
		}
		try {
			PreparedStatement pstmt = conn.prepareStatement("INSERT INTO partida (Juego,Duracion,Fecha,isValid,Num_Jugadores, Ganador, Comentario, hora) VALUES (?,?,?,?,?,?,?, ?)");
			pstmt.setInt(1,p.getJuego());
			pstmt.setInt(2,p.getDuracion());
			pstmt.setString(3,p.getFecha());
			pstmt.setBoolean(4,p.isValidada());
			pstmt.setInt(5,p.getNumJugadores());
			pstmt.setString(6,p.getGanador());
			pstmt.setString(7,p.getComentario());
			pstmt.setString(7,comentario);
			pstmt.setString(8,hora);
			affectedRows = pstmt.executeUpdate();
			pstmt.close();
			int idUltimaPartida = this.obtindreIdUltimaPartida(hora);
			logger.debug("Ultima id insertada partida " + idUltimaPartida);
			p.setIdPartida(idUltimaPartida);
			logger.debug("Id partida introducida en partida: " + p.getIdPartida());

			if(affectedRows == 0) {
				logger.error("No se ha modificado ninguna fila al insertar. Fallido.");
				logger.error("Ha surgido un error al intentar insertar la partida: \n "
						+ "**Partida**\n" + p.getJuego()+"\n"+p.getFecha()+"\n"+p.getGanador()
						+"\n"+p.getNumJugadores()+"\n"+p.getComentarios()+"\n");
			}else {
				correcto = true;
				logger.info("Partida insertada correctamente: \n "
						+ "**Partida**\n" + p.getJuego()+"\n"+p.getFecha()+"\n"+p.getGanador()
						+"\n"+p.getNumJugadores()+"\n"+p.getComentarios()+"\n");
			}
			int contador = 0;
			for (Usuari u : p.getParticipants()) {
				this.etiquetarUsuario(u, p, puntuaciones.get(contador));
				contador++;
			}


		}catch(SQLException e) {
			//TODO: log error
			logger.error("No se ha insertar la partida " + e.getMessage());
		}
		return correcto;

	}

	public Map mostrarPartidesUsuari(int idUsuari) throws SQLException
	{
		Connection conn = null;
		if(databaseTest == 1) {
			conn = MysqlDAOFactoryWithTestDB.crearConexio();
		}else {
			conn = MysqlDAOFactory.crearConexio();
		}
		Map<Partida, Integer> partidas = new HashMap<Partida, Integer>();
		List<Integer> listadeIdPartida = new ArrayList<Integer>();
		List<Integer> partidaGanada = new ArrayList<Integer>();
		ArrayList<Partida> partidasJugadas = new ArrayList<>();
		System.out.println("Anem a buscar les partides");
		int idPartida;
		int partidaGanadaEncontrada;
		ResultSet rsPartidesUsuari;
		String queryStr = "SELECT idPartida, partida_ganada  FROM partidasusuario WHERE idUsuario= ?";
		PreparedStatement pstmt = conn.prepareStatement(queryStr);
		System.out.println(idUsuari);
		pstmt.setInt(1,idUsuari);
		rsPartidesUsuari = pstmt.executeQuery();

		while(rsPartidesUsuari.next())
		{
			System.out.println("Dentro de una partida");
			idPartida = rsPartidesUsuari.getInt(1);
			partidaGanadaEncontrada = rsPartidesUsuari.getInt(2);
			partidaGanada.add(partidaGanadaEncontrada);
			listadeIdPartida.add(idPartida);
		}
		pstmt.close();
		rsPartidesUsuari.close();

		for(Integer idPartida1:listadeIdPartida)
		{
			ResultSet rsPartidesUsuari1;
			String queryStr1 = "SELECT idPartida, Juego,Num_Jugadores,Ganador,Comentario,Duracion,Fecha,isValid FROM partida WHERE idPartida= ?;";
			PreparedStatement pstmt1 = conn.prepareStatement(queryStr1);
			pstmt1.setInt(1,idPartida1);
			rsPartidesUsuari1 = pstmt1.executeQuery();
			int contador = 0;
			while(rsPartidesUsuari1.next())
			{
				System.out.println("RECORRIENDO RESULSET PARTIDAS");
				int midPartida = rsPartidesUsuari1.getInt(1);
				int midJuego = rsPartidesUsuari1.getInt(2);
				int mNumJugadores = rsPartidesUsuari1.getInt(3);
				String mganador = rsPartidesUsuari1.getString(4);
				String mcomentario = rsPartidesUsuari1.getString(5);
				int mduracion = rsPartidesUsuari1.getInt(6);
				String mfecha = rsPartidesUsuari1.getString(7);
				int misValid = rsPartidesUsuari1.getInt(8);
				Partida p = new Partida(midPartida, midJuego, mNumJugadores, mfecha, mNumJugadores, mganador, mcomentario);
				int ganada = listadeIdPartida.get(contador);
				partidasJugadas.add(p);
				contador++;
			}
			int contador2 = 0;
			for(Partida p  : partidasJugadas ){
				partidas.put(p,partidaGanada.get(contador2));
				contador2++;
			}

			pstmt1.close();
			rsPartidesUsuari1.close();
		}
		for (Map.Entry<Partida,Integer> entry : partidas.entrySet()){
			System.out.println("REcorriendo el map a devolver");
			System.out.println(entry.getKey().getIdPartida() + "/" + entry.getValue());
		}


		return partidas;

	}

	/*public Map mostrarPartidesUsuari(int idUsuari) throws SQLException
	{
		Connection conn = null;
		if(databaseTest == 1) {
			conn = MysqlDAOFactoryWithTestDB.crearConexio();
		}else {
			conn = MysqlDAOFactory.crearConexio();
		}
		Map<Partida, Integer> partidas = new HashMap<Partida, Integer>();
		List<Integer> listadeIdPartida = new ArrayList<Integer>();
		System.out.println("Anem a buscar les partides");
		int idPartida;
		ResultSet rsPartidesUsuari;
		String queryStr = "SELECT idPartida, partida_ganada  FROM partidasusuario WHERE idUsuario= ?";
		PreparedStatement pstmt = conn.prepareStatement(queryStr);
		System.out.println(idUsuari);
		pstmt.setInt(1,idUsuari);
		rsPartidesUsuari = pstmt.executeQuery();
		ArrayList<Integer> partidaGanada = null;
		while(rsPartidesUsuari.next())
		{
			System.out.println("Dentro de una partida");
			idPartida = rsPartidesUsuari.getInt(1);
			partidaGanada.add(rsPartidesUsuari.getInt(2));
			listadeIdPartida.add(idPartida);
		}
		pstmt.close();
		rsPartidesUsuari.close();

		for(Integer idPartida1:listadeIdPartida)
		{
			ResultSet rsPartidesUsuari1;
			String queryStr1 = "SELECT idPartida, Juego,Num_Jugadores,Ganador,Comentario,Duracion,Fecha,isValid FROM partida WHERE idPartida= ?;";
			PreparedStatement pstmt1 = conn.prepareStatement(queryStr1);
			pstmt1.setInt(1,idPartida1);
			rsPartidesUsuari1 = pstmt1.executeQuery();
			int contador = 0;
			while(rsPartidesUsuari1.next())
			{
				System.out.println("RECORRIENDO RESULSET PARTIDAS");
				int midPartida = rsPartidesUsuari1.getInt(1);
				int midJuego = rsPartidesUsuari1.getInt(2);
				int mNumJugadores = rsPartidesUsuari1.getInt(3);
				String mganador = rsPartidesUsuari1.getString(4);
				String mcomentario = rsPartidesUsuari1.getString(5);
				int mduracion = rsPartidesUsuari1.getInt(6);
				String mfecha = rsPartidesUsuari1.getString(7);
				int misValid = rsPartidesUsuari1.getInt(8);
				Partida p = new Partida(midPartida, midJuego, mNumJugadores, mfecha, mNumJugadores, mganador, mcomentario);
				int ganada = listadeIdPartida.get(contador);
				System.out.println("paRTIDAS INSERTADA" + p.getFecha());
				System.out.println("ganada"+ ganada);
				partidas.put(p,ganada);
				contador++;
			}
			pstmt1.close();
			rsPartidesUsuari1.close();
		}

		return partidas;

	}*/

	/*public int obtindreIdUltimaPartida()
	{
		int idPartida = 0;
		Connection conn = null;
		if(databaseTest == 1) {
			conn = MysqlDAOFactoryWithTestDB.crearConexio();
		}else {
			conn = MysqlDAOFactory.crearConexio();
		}
		try {
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT P.idPartida FROM partida P");
			while(rs.next())
			{
				idPartida++;
			}

			if(idPartida < 1)
			{
				logger.error("Error al recoger la ultima id insertada en partida");
			}
		}catch(SQLException e) {
			//TODO: log error
			logger.error("Error al intentar recoger la ultima ID insertada en partida " + e.getMessage());
		}
		return idPartida;

	}*/

	public int obtindreIdUltimaPartida(String hora) {
		//TODO: buscar usuarios y anadirlos a la lista de usuarios de partida, y en la BD, en la tabla PartidasUsuario
		Connection conn = null;
		int idUltima = 0;
		int affectedRows = 0;

		if(databaseTest == 1) {
			conn = MysqlDAOFactoryWithTestDB.crearConexio();
		}else {
			conn = MysqlDAOFactory.crearConexio();
		}
		logger.debug("LA HORA EN LA FUNCION OBTENER ULTIMA ID ES:" + hora);
		PreparedStatement pstmt;
		try {
			ResultSet idUltimars;
			String queryStr1 = "SELECT idPartida FROM partida WHERE hora = ?";
			PreparedStatement pstmt1 = conn.prepareStatement(queryStr1);
			pstmt1.setString(1,hora);
			idUltimars = pstmt1.executeQuery();
			while(idUltimars.next()) {
				idUltima = idUltimars.getInt(1);
			}

			if(affectedRows == 0) {
				logger.error("No se ha modificado ninguna fila al insertar. Fallido.");
			}else {
				logger.info("Id encontrada con exito:");

			}
		} catch (SQLException e) {
			logger.error("No se ha podido etiquetar usuario " + e.getMessage());
		}

		return idUltima;

	}


}
