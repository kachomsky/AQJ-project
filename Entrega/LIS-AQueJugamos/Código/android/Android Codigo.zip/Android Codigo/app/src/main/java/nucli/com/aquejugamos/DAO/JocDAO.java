package nucli.com.aquejugamos.DAO;

import java.util.ArrayList;

import nucli.com.aquejugamos.general.Joc;

public interface JocDAO {
	
	public void mostrarJocs();
	public ArrayList<Joc> carregarUltimsJocs();
	public ArrayList<Joc> carregarJocs();
	public ArrayList<Joc> busquedaAvanzada(String nom , String nJugadors , String temps, String categoria , String genere);
	public Joc buscarJocPerId(int idJoc);
	public Joc buscarJocPerNom(String nom);
	public ArrayList<String> getTodasCategorias();
    public ArrayList<String> getTodosTipos();
	
}
