package com.example.mksh_pc.aqj;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.daimajia.slider.library.Animations.DescriptionAnimation;
import com.daimajia.slider.library.SliderLayout;
import com.daimajia.slider.library.SliderTypes.BaseSliderView;
import com.daimajia.slider.library.SliderTypes.TextSliderView;
import com.daimajia.slider.library.Tricks.ViewPagerEx;
import com.ldealmei.libs.carousel.CarouselPicker;
import com.ldealmei.libs.carousel.ItemPicker;
import com.squareup.picasso.Picasso;

import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import nucli.com.aquejugamos.DAO.DAOFactory;
import nucli.com.aquejugamos.DAO.JocDAO;
import nucli.com.aquejugamos.DAO.UsuarioDAO;
import nucli.com.aquejugamos.general.Joc;
import nucli.com.aquejugamos.general.Usuari;

public class HomeFragment extends Fragment implements BaseSliderView.OnSliderClickListener, ViewPagerEx.OnPageChangeListener{
    private Usuari userLogeado;
    public static HomeFragment newInstance(){
        HomeFragment fragment = new HomeFragment();
        return fragment;
    }

    CarouselPicker carouselPicker1, carouselPicker2, carouselPicker3;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_home, container, false);
        SharedPreferences prefs = getActivity().getSharedPreferences("login", Context.MODE_PRIVATE);
        int idUsuario = prefs.getInt("id",0);
        String nomUsuario = prefs.getString("nombre","");
        String password = prefs.getString("password","");
        String email = prefs.getString("email","");
        int activo = prefs.getInt("activo",0);
        int bloqueado = prefs.getInt("bloqueado",0);
        int admin = prefs.getInt("admin",0);
        String grupo = prefs.getString("grupo","");
        String fecha = prefs.getString("fecha","");
        String provincia = prefs.getString("provincia","");
        String nickname = prefs.getString("nickname","");
        userLogeado = new Usuari(idUsuario, nomUsuario, password, email,activo,bloqueado,admin,grupo,fecha,provincia,nickname);

        /*carouselPicker1 = (CarouselPicker) view.findViewById(R.id.carouselPicker1);
        carouselPicker2 = (CarouselPicker) view.findViewById(R.id.carouselPicker2);
        carouselPicker3 = (CarouselPicker) view.findViewById(R.id.carouselPicker3);
        //Lista novedades
        List<ItemPicker> itemNovedades = new ArrayList<>();

        itemNovedades.add(new ItemPicker(R.mipmap.ic_launcher_round,"Banana"));
        itemNovedades.add(new ItemPicker(R.mipmap.ic_launcher_round,"Grapes"));
        itemNovedades.add(new ItemPicker(R.mipmap.ic_launcher_round,"Orange"));
        itemNovedades.add(new ItemPicker(R.mipmap.ic_launcher_round,"Banana"));
        itemNovedades.add(new ItemPicker(R.mipmap.ic_launcher_round,"Grapes"));
        itemNovedades.add(new ItemPicker(R.mipmap.ic_launcher_round,"Orange"));
        itemNovedades.add(new ItemPicker(R.mipmap.ic_launcher_round,"Banana"));
        itemNovedades.add(new ItemPicker(R.mipmap.ic_launcher_round,"Grapes"));
        itemNovedades.add(new ItemPicker(R.mipmap.ic_launcher_round,"Orange"));

        Map<String, Bitmap> novedades = new HashMap<String, Bitmap>();
        try {
            novedades = new getNovedadesJuegos().execute().get();
        }catch (Exception e){
            Log.e("HOME", "Error al cargar las novedades");
        }

        int i = 0;
        for (Map.Entry<String, Bitmap> entry : novedades.entrySet())
        {

            System.out.println(entry.getKey() + "/" + entry.getValue());
            Bitmap m = null;
            Drawable d = new BitmapDrawable(getResources(), entry.getValue());
            //Bitmap myImage = BitmapFactory.decodeResource(getResources(), R.drawable.myImageName);
            int drawableId = getResources().getIdentifier("foo"+i, "drawable", getActivity().getPackageName());
            itemNovedades.add(new ItemPicker(R.mipmap.ic_launcher_round ,entry.getKey()));
            //itemNovedades.add(new ItemPicker(R.mipmap.ic_launcher_round,"Orange"));
            i++;
        }

        carouselPicker1.addList(itemNovedades).build(this.getActivity());

        List<ItemPicker> itemMasJugados = new ArrayList<>();

        itemMasJugados.add(new ItemPicker(R.mipmap.ic_launcher_round,"Banana"));
        itemMasJugados.add(new ItemPicker(R.mipmap.ic_launcher_round,"Grapes"));
        itemMasJugados.add(new ItemPicker(R.mipmap.ic_launcher_round,"Orange"));
        itemMasJugados.add(new ItemPicker(R.mipmap.ic_launcher_round,"Banana"));
        itemMasJugados.add(new ItemPicker(R.mipmap.ic_launcher_round,"Grapes"));
        itemMasJugados.add(new ItemPicker(R.mipmap.ic_launcher_round,"Orange"));
        itemMasJugados.add(new ItemPicker(R.mipmap.ic_launcher_round,"Banana"));
        itemMasJugados.add(new ItemPicker(R.mipmap.ic_launcher_round,"Grapes"));
        itemMasJugados.add(new ItemPicker(R.mipmap.ic_launcher_round,"Orange"));

        carouselPicker2.addList(itemMasJugados).build(this.getActivity());
        */
        Map<String, String> novedades = new HashMap<String, String>();

        try {
            novedades = new getNovedadesJuegos().execute().get();
        }catch (Exception e){
            Log.e("HOME", "Error al cargar las novedades");
        }

        final SliderLayout mDemoSlider;
        final SliderLayout mDemoSlider2;
        mDemoSlider = (SliderLayout)view.findViewById(R.id.slider);
        mDemoSlider2 = (SliderLayout)view.findViewById(R.id.slider2);

        for(String name : novedades.keySet()){
            TextSliderView textSliderView = new TextSliderView(this.getActivity());
            // initialize a SliderLayout
            textSliderView
                    .description(name)
                    .image(novedades.get(name))
                    .setScaleType(BaseSliderView.ScaleType.Fit)
                    .setOnSliderClickListener(this);

            //add your extra information
            textSliderView.bundle(new Bundle());
            textSliderView.getBundle()
                    .putString("extra",name);

            mDemoSlider.addSlider(textSliderView);
        }
        //mDemoSlider.stopAutoCycle();
        mDemoSlider.setPresetTransformer(SliderLayout.Transformer.Accordion);
        mDemoSlider.setPresetIndicator(SliderLayout.PresetIndicators.Center_Bottom);
        mDemoSlider.setCustomAnimation(new DescriptionAnimation());
        mDemoSlider.setDuration(4000);

        TextView txtView = (TextView)view.findViewById(R.id.miSalonHome);

        ArrayList<Joc> jocs = new ArrayList<>();
        try{
            jocs = new recogerSalon().execute().get();
        }catch (Exception e){
            Log.e("HOME", e.getMessage());
        }


        if(prefs.getBoolean("isLogged", false)) {
            txtView.setVisibility(View.VISIBLE);
            for (Joc joc : jocs) {
                TextSliderView textSliderView = new TextSliderView(this.getActivity());
                // initialize a SliderLayout
                textSliderView
                        .description(joc.getNomJoc())
                        .image(joc.getImagen())
                        .setScaleType(BaseSliderView.ScaleType.Fit)
                        .setOnSliderClickListener(this);

                //add your extra information
                textSliderView.bundle(new Bundle());
                textSliderView.getBundle()
                       .putString("extra",joc.getNomJoc());

                mDemoSlider2.addSlider(textSliderView);
            }
            //mDemoSlider2.stopAutoCycle();
            mDemoSlider2.setPresetTransformer(SliderLayout.Transformer.Accordion);
            mDemoSlider2.setPresetIndicator(SliderLayout.PresetIndicators.Center_Bottom);
            mDemoSlider2.setCustomAnimation(new DescriptionAnimation());
            mDemoSlider2.setDuration(4000);
        }else{
            txtView.setVisibility(View.INVISIBLE);
        }


        return view;
    }

    @Override
    public void onSliderClick(BaseSliderView slider) {

    }

    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

    }

    @Override
    public void onPageSelected(int position) {

    }

    @Override
    public void onPageScrollStateChanged(int state) {

    }

    private class getNovedadesJuegos extends AsyncTask<Void, Void, Map>{


        @Override
        protected Map doInBackground(Void... voids) {

            Log.d("HOME", "Cargando novedades juegos");
            DAOFactory daoFactory = DAOFactory.getDAOFactory(DAOFactory.MYSQL);
            JocDAO jocDAO = daoFactory.getJocDAO();
            ArrayList<Joc> novedades = jocDAO.carregarUltimsJocs();
            Log.d("HOME", "Novedades cargadas");
            Bitmap bmp = null;
            Map<String, String> novedadesMap = new HashMap<String, String>();

            for(Joc j : novedades){
                if(!j.getImagen().equals("")) {
                    try {
                        Log.d("HOME","Cargando la URL " + j.getImagen());
                        novedadesMap.put(j.getNomJoc(), j.getImagen());
                    } catch (Exception e) {
                        Log.e("HOME", "Error al cargar la url" + j.getImagen());
                    }
                }
            }

            return novedadesMap;
        }
    }

    private class recogerSalon extends AsyncTask<Void, Void, ArrayList<Joc>> {


        @Override
        protected ArrayList doInBackground(Void... voids) {
            ArrayList<Joc> jocs = new ArrayList<>();
            Log.d("MAIN", "Recogeiendo juegos del salon");
            DAOFactory daoFactory = DAOFactory.getDAOFactory(DAOFactory.MYSQL);
            UsuarioDAO usuarioDAO = daoFactory.getUsuarioDAO();
            try{
                jocs = usuarioDAO.carregarLlistaFavoritsUser(userLogeado);
            }catch (Exception e){
                Log.e("MAIN", e.getMessage());
            }

            Log.d("DETALLES", "Datos recogidos");

            return jocs;
        }
    }

}