package nucli.com.aquejugamos.test;

import static org.junit.Assert.*;
import java.util.ArrayList;
import org.junit.Test;
import nucli.com.aquejugamos.DAO.DAOFactory;
import nucli.com.aquejugamos.DAO.JocAlternatiuDAO;
import nucli.com.aquejugamos.general.JocAlternatiu;
import nucli.com.aquejugamos.general.JocTaula;


public class JocAlternatiuDAOMysqlImpTest {

	DAOFactory mysqlFactory = DAOFactory.getDAOFactory(DAOFactory.MYSQLTEST);
	JocAlternatiuDAO jocAlternatiuDAO = mysqlFactory.getJocAlternatiuDAO();
	
	@Test
	public void carregarJocsAlternatiusTest() {
		jocAlternatiuDAO.carregarJocsAlternatius();
		ArrayList<JocAlternatiu> jocsAlternatiusCorrectes = new ArrayList<JocAlternatiu>();
		
		JocAlternatiu j1 = new JocAlternatiu(0,2,"Alternativo", "Tres en raya", 0, 3,
				"2", "1min", "tipo", "raya", "100", 1,
				 "", "Lapiz,Boli");		
		
		jocsAlternatiusCorrectes.add(j1);		
		
		assertEquals(jocAlternatiuDAO.getLlistaJocsAlternatius().get(0).getDescripcio(),jocsAlternatiusCorrectes.get(0).getDescripcio());
		assertEquals(jocAlternatiuDAO.getLlistaJocsAlternatius().get(0).getDificultat(), jocsAlternatiusCorrectes.get(0).getDificultat());
		assertEquals(jocAlternatiuDAO.getLlistaJocsAlternatius().get(0).getDuracio(), jocsAlternatiusCorrectes.get(0).getDuracio());
		assertEquals(jocAlternatiuDAO.getLlistaJocsAlternatius().get(0).getEdat(), jocsAlternatiusCorrectes.get(0).getEdat());
		assertEquals(jocAlternatiuDAO.getLlistaJocsAlternatius().get(0).getIdCategoria(), jocsAlternatiusCorrectes.get(0).getIdCategoria());		
		assertEquals(jocAlternatiuDAO.getLlistaJocsAlternatius().get(0).getIdTipo(), jocsAlternatiusCorrectes.get(0).getIdTipo());
		assertEquals(jocAlternatiuDAO.getLlistaJocsAlternatius().get(0).getImagen(), jocsAlternatiusCorrectes.get(0).getImagen());
		assertEquals(jocAlternatiuDAO.getLlistaJocsAlternatius().get(0).getNomCategoria(), jocsAlternatiusCorrectes.get(0).getNomCategoria());
		assertEquals(jocAlternatiuDAO.getLlistaJocsAlternatius().get(0).getNomJoc(), jocsAlternatiusCorrectes.get(0).getNomJoc());
		assertEquals(jocAlternatiuDAO.getLlistaJocsAlternatius().get(0).getNumeroJugadors(), jocsAlternatiusCorrectes.get(0).getNumeroJugadors());
		assertEquals(jocAlternatiuDAO.getLlistaJocsAlternatius().get(0).getIdTipo(), jocsAlternatiusCorrectes.get(0).getIdTipo());
		assertEquals(jocAlternatiuDAO.getLlistaJocsAlternatius().get(0).getValoracio(), jocsAlternatiusCorrectes.get(0).getValoracio());
		assertEquals(jocAlternatiuDAO.getLlistaJocsAlternatius().get(0).getMaterials(), jocsAlternatiusCorrectes.get(0).getMaterials());
				
	}

}
