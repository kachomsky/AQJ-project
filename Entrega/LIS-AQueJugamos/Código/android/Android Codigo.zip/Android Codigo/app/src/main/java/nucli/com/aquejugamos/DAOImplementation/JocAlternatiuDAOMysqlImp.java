package nucli.com.aquejugamos.DAOImplementation;

import java.sql.Connection;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import nucli.com.aquejugamos.DAO.JocAlternatiuDAO;
import nucli.com.aquejugamos.DAO.MysqlDAOFactory;
import nucli.com.aquejugamos.general.JocAlternatiu;
import nucli.com.aquejugamos.test.MysqlDAOFactoryWithTestDB;

import java.sql.ResultSet;
import java.sql.SQLException;


public class JocAlternatiuDAOMysqlImp implements JocAlternatiuDAO{
	
	private List<JocAlternatiu> llistaAlternatius = new ArrayList<JocAlternatiu>();
	private int databaseTest;
	/** Logger **/
	private static Logger logger = LoggerFactory.getLogger(JocAlternatiuDAOMysqlImp.class);
	
	
	public JocAlternatiuDAOMysqlImp() {};
	
	/** Constructor que se usara si queremos usar la base de datos de test **/
	public JocAlternatiuDAOMysqlImp(int databaseTest) {
		this.databaseTest = databaseTest;
	};
	
	public void carregarJocsAlternatius() {
		Connection conn = null;
		if(databaseTest == 1) {
			conn = MysqlDAOFactoryWithTestDB.crearConexio();
		}else {
			conn = MysqlDAOFactory.crearConexio();
		}
		try {
		Statement stmt = conn.createStatement();
		ResultSet rs = stmt.executeQuery("SELECT J.idJuego, J.idCategoria, C.NombreCategoria, J.NombreJuego, J.Dificultad, J.Edad,J.Jugadores,J.Tiempo, T.Nombre, J.Descripcion, J.Valoracion, J.Materiales, J.idTipo, J.Imagen FROM juego J, categoria C,tipo T WHERE J.idCategoria=C.idCategoria AND J.idTipo=T.idTipo AND C.idCategoria=2;");
		
		while(rs.next())
		{
			int idJuego=rs.getInt(1);
			int idCategoria=rs.getInt(2);
			String nombreCategoria = rs.getString(3);
			String nombreJuego=rs.getString(4);
			int dificultad = rs.getInt(5);
			int edat = rs.getInt(6);
			String numeroJugadores = rs.getString(7);
			String tiempo = rs.getString(8);
			String tipo = rs.getString(9);
			String descripcion = rs.getString(10);
			String valoracion = rs.getString(11);
			String materiales = rs.getString(12);
			int idTipo =rs.getInt(13);
			String imagen = rs.getString(14);
			JocAlternatiu joc = new JocAlternatiu(idJuego,idCategoria,nombreCategoria,nombreJuego,dificultad,edat, numeroJugadores,tiempo, tipo, descripcion,valoracion,idTipo, imagen,  materiales);
			llistaAlternatius.add(joc);			
		}
		rs.close();
		stmt.close();
		}catch (SQLException e) {
			//TODO:log error
			logger.error("*** ERROR SQL CARGANDO JUEGOS ALTERNATIVOS *** ");
		}
		
	}

	@Override
	public List<JocAlternatiu> getLlistaJocsAlternatius() {
		// TODO Auto-generated method stub
		return this.llistaAlternatius;
	}
}
