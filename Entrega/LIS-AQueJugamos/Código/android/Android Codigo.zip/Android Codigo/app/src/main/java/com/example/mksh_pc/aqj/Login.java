package com.example.mksh_pc.aqj;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import nucli.com.aquejugamos.DAO.DAOFactory;
import nucli.com.aquejugamos.DAO.UsuarioDAO;
import nucli.com.aquejugamos.general.Usuari;

public class Login extends AppCompatActivity implements View.OnClickListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SharedPreferences pref = getSharedPreferences("login", Context.MODE_PRIVATE);
        if(pref.getBoolean("isLogged", false)){
            logout();
            Toast.makeText(Login.this, "Has cerrado sesión con exito!", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        }
        setContentView(R.layout.activity_iniciar_sesion);
        Button aceptarLogin = (Button) findViewById(R.id.isAceptarBtn);
        aceptarLogin.setOnClickListener(this);
        //Button logout = (Button) findViewById(R.id.logout);
        //logout.setOnClickListener(this);
    }

    public void onClick(View view){
        switch(view.getId()) {
            case R.id.isAceptarBtn:
                guardarPreferencias();
                cargarPreferencias();
                break;

            /*case R.id.logout:
                logout();
                cargarPreferencias();
                break;*/
        }
    }

    private void guardarPreferencias(){
        SharedPreferences pref = getSharedPreferences("login", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = pref.edit();
        EditText email = (EditText) findViewById(R.id.isEmailET);
        EditText password = (EditText) findViewById(R.id.isContraseñaET);
        ExecutorService executor = Executors.newCachedThreadPool();
        Future<Usuari> loginSubmit = executor.submit(new Login.login(email.getText().toString(), password.getText().toString()));

        try{
            Usuari usuarioLogueado = loginSubmit.get();

            if(usuarioLogueado != null){
                editor.putBoolean("isLogged", true);
                editor.putInt("id", usuarioLogueado.getIdUsuari());
                editor.putString("nombre", usuarioLogueado.getNomUsuari());
                editor.putString("password", usuarioLogueado.getPassword());
                editor.putString("email", usuarioLogueado.getMail());
                editor.putInt("activo", usuarioLogueado.getActivo());
                editor.putInt("bloqueado", usuarioLogueado.getBloqueado());
                editor.putInt("admin", usuarioLogueado.getIsAdmin());
                editor.putString("grupo", usuarioLogueado.getGrupo());
                editor.putString("fecha", usuarioLogueado.getFecha());
                editor.putString("provincia", usuarioLogueado.getProvincia());
                editor.putString("nickname", usuarioLogueado.getNickname());
                editor.commit();
            }
            else{
                editor.putBoolean("isLogged", false);
            }
        }catch(Exception e){
            Log.e("ERROR", e.getMessage());
        }

    }

    private void cargarPreferencias(){
        SharedPreferences pref = getSharedPreferences("login", Context.MODE_PRIVATE);
        System.out.println(pref.getString("email", "No has iniciado sesion"));
        if(pref.getBoolean("isLogged", false)){
            System.out.println("Logueado");
            Toast.makeText(Login.this, "Has iniciado sesión con exito!", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        }else{
            System.out.println("No logueado");
            Toast.makeText(Login.this, "Usuario o password incorrectos", Toast.LENGTH_LONG).show();
        }
    }

    public void logout(){
        SharedPreferences pref = getSharedPreferences("login", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = pref.edit();
        editor.clear().commit();
    }

    public class login implements Callable<Usuari> {

        private String email;
        private String password;

        public login(String email, String password){
            this.email = email;
            this.password = password;
        }

        @Override
        public Usuari call() throws Exception {
            DAOFactory mysqlFactory = DAOFactory.getDAOFactory(DAOFactory.MYSQL);
            UsuarioDAO usuarioDAO = mysqlFactory.getUsuarioDAO();
            Usuari u = usuarioDAO.loginUsuari(this.email,this.password);
            return u;
        }
    }
}
