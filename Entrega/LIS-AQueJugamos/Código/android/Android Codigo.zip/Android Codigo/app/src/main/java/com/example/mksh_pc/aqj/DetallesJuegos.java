package com.example.mksh_pc.aqj;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import nucli.com.aquejugamos.DAO.DAOFactory;
import nucli.com.aquejugamos.DAO.JocDAO;
import nucli.com.aquejugamos.DAO.UsuarioDAO;
import nucli.com.aquejugamos.general.Joc;

public class DetallesJuegos extends AppCompatActivity implements View.OnClickListener{
    private int idJuego;
    private int idUser;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_juego);
        Intent intent = getIntent();
        idJuego = intent.getIntExtra("idJuego",0);
        SharedPreferences prefs = getSharedPreferences("login", Context.MODE_PRIVATE);
        idUser = prefs.getInt("id",0);
        Joc jocDetall = null;
        try{
            jocDetall = new getJuegoSeleccionado(idJuego).execute().get();
        }catch (Exception e){
            Log.e("DETALLES JUEGO", "Error al recoger los detalles del juego");
        }

        //Get all elements from layout
        TextView nombre = (TextView) findViewById(R.id.tituloTVJ);
        ImageView imagen= (ImageView) findViewById(R.id.imgIVJ);
        TextView valoracion = (TextView) findViewById(R.id.valoracionTVJ);
        TextView numJugadores = (TextView) findViewById(R.id.nJugadoresTVJ);
        TextView categoria = (TextView) findViewById(R.id.categoriaTVJ);
        TextView tipo = (TextView) findViewById(R.id.tipoTVJ);
        TextView duracion = (TextView) findViewById(R.id.duracionTVJ);
        TextView descripcion = (TextView) findViewById(R.id.descripcionTVJ);
        TextView materiales = (TextView) findViewById(R.id.materialesTVJ);
        TextView materialesTitulo = (TextView) findViewById(R.id.textView6);

        if(jocDetall.getMaterials().equals("")){
            materiales.setVisibility(View.INVISIBLE);
            materialesTitulo.setVisibility(View.INVISIBLE);
        }else{
            materiales.setText(jocDetall.getMaterials());
        }

        nombre.setText(jocDetall.getNomJoc());
        valoracion.setText(jocDetall.getValoracio());
        numJugadores.setText(jocDetall.getNumeroJugadors());
        categoria.setText(jocDetall.getNomCategoria());
        tipo.setText(jocDetall.getTipo());
        duracion.setText(jocDetall.getDuracio());
        descripcion.setText(jocDetall.getDescripcio());
        if(!jocDetall.getImagen().equals(""))
            Picasso.with(this).load(jocDetall.getImagen()).into(imagen);

        Button juegoAnadir = findViewById(R.id.añadirJuegoBtn);
        juegoAnadir.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        //todo añadir
        boolean insertado = false;
        try{
            insertado = new anadirASalon().execute().get();
        }catch (Exception e){
            Log.e("DETALLES",e.getMessage());
        }

        if(insertado){
            Toast.makeText(this, "Añadido a tu salón con exito!", Toast.LENGTH_LONG).show();
        }else{
            Toast.makeText(this, "Ha ocurrido un error a la hora de añadir a tu salon", Toast.LENGTH_LONG).show();
        }


    }



    private class getJuegoSeleccionado extends AsyncTask<Void, Void, Joc> {

        private int idJuego;

        public getJuegoSeleccionado(int idJuego){
            this.idJuego = idJuego;
        }

        @Override
        protected Joc doInBackground(Void... voids) {
            Log.d("DETALLES JUEGO", "Cargando detalles juegos");
            DAOFactory daoFactory = DAOFactory.getDAOFactory(DAOFactory.MYSQL);
            JocDAO jocDAO = daoFactory.getJocDAO();
            Joc joc = jocDAO.buscarJocPerId(idJuego);
            return joc;
        }
    }

    private class anadirASalon extends AsyncTask<Void, Void, Boolean>{


        @Override
        protected Boolean doInBackground(Void... voids) {

            Log.d("DETALLES", "Añadiendo a salon");
            DAOFactory daoFactory = DAOFactory.getDAOFactory(DAOFactory.MYSQL);
            UsuarioDAO usuarioDAO = daoFactory.getUsuarioDAO();
            boolean encontrado = usuarioDAO.afegirLlistaPreferits(idJuego, idUser);
            Log.d("DETALLES", "Añadido al salon");


            return encontrado;
        }
    }
}
