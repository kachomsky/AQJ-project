package com.example.mksh_pc.aqj;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import nucli.com.aquejugamos.DAO.DAOFactory;
import nucli.com.aquejugamos.DAO.JocDAO;
import nucli.com.aquejugamos.DAO.PartidaDAO;
import nucli.com.aquejugamos.DAO.UsuarioDAO;
import nucli.com.aquejugamos.general.Joc;
import nucli.com.aquejugamos.general.JocTaula;
import nucli.com.aquejugamos.general.Partida;
import nucli.com.aquejugamos.general.Usuari;


public class CrearPartidaActivity extends AppCompatActivity implements View.OnClickListener{

    ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
                super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crear_partida);

        android.widget.Button botonBusqueda = findViewById(R.id.subirPartida);
        botonBusqueda.setOnClickListener(this);


        EditText numJugadores = ((EditText)findViewById(R.id.editMatchPlayers));
        numJugadores.addTextChangedListener(new MyTextWatcher(this));
        //Partida p = new Partida(0, int juego, int duracion, String fecha, boolean validada, ArrayList<
        //Usuari > participants, ArrayList<String> comentarios, int numJugadores, String ganador);

    }

    public class MyTextWatcher implements TextWatcher {
        Context c;
        public MyTextWatcher(Context c){
            this.c = c;
        }
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {

        }

        @Override
        public void afterTextChanged(Editable s) {
            Log.d("PARTIDAS", "Dentro de afterTextChanged");
            String valorEditText = ((EditText) findViewById(R.id.editMatchPlayers)).getText().toString();
            Log.d("PARTIDAS", "El valor de el campo de texto es: " + valorEditText);
            if(!valorEditText.equals("")) {
                listView = (ListView) findViewById(R.id.playersList);
                ArrayList<String> participantes = new ArrayList<>();
                int numParticipantes = Integer.parseInt(valorEditText);

                for (int i = 0; i < numParticipantes; i++) {
                    participantes.add(String.valueOf(i));
                }
                PartidasAdapter adapter;
                adapter = new PartidasAdapter(c, participantes);
                listView.setAdapter(adapter);
            }else{
                Log.d("PARTIDAS", "El campo de num jugadores esta vacio" );
            }
            //((TextView)findViewById(R.id.numcaratteri)).setText(String.format(getString(R.string.caratteri), s.length()));
            //Toast.makeText(CrearPartidaActivity.this, ((EditText) findViewById(R.id.editMatchPlayers)).getText().toString() , Toast.LENGTH_LONG).show();
        }
    }


        public class PartidasAdapter extends ArrayAdapter<String> {

            public PartidasAdapter(@NonNull Context context, ArrayList<String> listaJuegos) {
                super(context, 0, listaJuegos);
            }

        @Override
        public View getView(int position, View convertView, ViewGroup parent){

            if (convertView == null) {
                convertView = LayoutInflater.from(getContext()).inflate(R.layout.fila_lista_jugadores_partida, parent, false);
            }

            TextView numeroJugador = (TextView) convertView.findViewById(R.id.enumPlayer);

            numeroJugador.setText(String.valueOf(position));

            return convertView;
        }
    }

    private class buscarJocPerNom extends AsyncTask<Void, Void, Joc> {

        private String nom;

        public buscarJocPerNom(String nom){
            this.nom = nom;
        }

        @Override
        protected Joc doInBackground(Void... voids) {

            Log.d("PARTIDA", "Buscando el juego seleccionado");
            DAOFactory daoFactory = DAOFactory.getDAOFactory(DAOFactory.MYSQL);
            JocDAO jocDAO = daoFactory.getJocDAO();
            Joc joc= jocDAO.buscarJocPerNom(this.nom);
            return joc;
        }
    }

    private class buscarUsuariPerNickname extends AsyncTask<Void, Void, Usuari> {

        private String nom;

        public buscarUsuariPerNickname(String nom){
            this.nom = nom;
        }

        @Override
        protected Usuari doInBackground(Void... voids) {
            Log.d("PARTIDA", "Buscando el juego seleccionado");
            DAOFactory daoFactory = DAOFactory.getDAOFactory(DAOFactory.MYSQL);
            UsuarioDAO usuarioDAO = daoFactory.getUsuarioDAO();
            Usuari usuariTrobat = usuarioDAO.buscarUsuarioPorNickname(nom);
            return usuariTrobat;
        }
    }

    private class subirPartida extends AsyncTask<Void, Void, Boolean> {

        private Partida partidaJugada;
        ArrayList<Integer> puntuaciones;

        public subirPartida(Partida partidaJugada, ArrayList<Integer> puntuaciones){
            this.partidaJugada = partidaJugada;
            this.puntuaciones = puntuaciones;
        }

        @Override
        protected Boolean doInBackground(Void... voids) {
            Log.d("PARTIDA", "Subiendo partida");
            DAOFactory daoFactory = DAOFactory.getDAOFactory(DAOFactory.MYSQL);
            PartidaDAO partidaDAO = daoFactory.getPartidaDAO();
            boolean subidaCorrectamente = partidaDAO.pujarPartida(partidaJugada, puntuaciones);
            return subidaCorrectamente;
        }
    }

    @Override
    public void onClick(View v) {
        Log.d("PARTIDA", "Has seleccionado el boton para subir partida");
        TextView editGame = findViewById(R.id.editGameNameMatch);
        String nombreJuego = editGame.getText().toString();
        Joc jocPartida = null;
        try{
            jocPartida = new buscarJocPerNom(nombreJuego).execute().get();
        }catch (Exception e){
            Log.d("PARTIDA", "Error al recoger el valor del nombre del juego");
        }

        ArrayList<Usuari> usuarios = new ArrayList<>();
        ArrayList<Integer> puntuaciones = new ArrayList<Integer>();

        for ( int i = 0 ; i < listView.getCount() ; i++){
            View filaLista = getViewByPosition(i,listView);
            EditText editNombreJugador = filaLista.findViewById(R.id.nombreJugador);
            String nicknameUsuario = editNombreJugador.getText().toString();
            Log.d("PARTIDA", nicknameUsuario);

            try{
                Usuari usuarioEncontrado = new buscarUsuariPerNickname(nicknameUsuario).execute().get();
                usuarios.add(usuarioEncontrado);
            }catch (Exception e){
                Log.e("PARTIDA" , "Error al recoger el usuario por nickname");
            }

            EditText editPuntosJugador = filaLista.findViewById(R.id.playerPoints);
            puntuaciones.add(Integer.parseInt(editPuntosJugador.getText().toString()));

        }
        int numJugadores = Integer.parseInt(((EditText) findViewById(R.id.editMatchPlayers)).getText().toString());
        EditText duracionEdit = findViewById(R.id.editMatchTime);
        int duracion = Integer.parseInt(duracionEdit.getText().toString());
        Date date = new Date();
        String fecha = new SimpleDateFormat("yyyy-MM-dd").format(date);

        int maxPunt = -1;
        int posicionGanador = 0;

        for(int i = 0; i < numJugadores; i++){
            if(puntuaciones.get(i) > maxPunt){
                maxPunt = puntuaciones.get(i);
                posicionGanador = i;
            }
        }

        String ganador = usuarios.get(posicionGanador).getNickname();
        ArrayList<String> comentarios = new ArrayList<String>();
        comentarios.add("");
        Partida p = new Partida(0, jocPartida.getIdJuego(), duracion, fecha, false, usuarios, comentarios, numJugadores, ganador);
        boolean subidaCorrecta = false;
        try{
            subidaCorrecta = new subirPartida(p, puntuaciones).execute().get();
        }catch (Exception e){
            Log.e("PARTIDA", "Error al subir la partida");
        }

        if(subidaCorrecta){
            Toast.makeText(this, "Has subido la partida correctamente!", Toast.LENGTH_LONG).show();
        }else{
            Toast.makeText(this, "Error al subir la partida!", Toast.LENGTH_LONG).show();
        }

        /*for (int i=0;i<adapter.getCount();i++){
            Log.d("PARTIDA", adapter.getItem(i));
        }*/
        //public Usuari(int idUsuari, String nomUsuari, String password, String mail, int activo, int bloqueado, int isAdmin,
        //				  String grupo, String fecha, String provincia,String nickname) {
        //Partida p = new Partida(0, int juego, int duracion, String fecha, boolean validada, ArrayList<
        //Usuari > participants, ArrayList<String> comentarios, int numJugadores, String ganador);

    }

    public View getViewByPosition(int position, ListView listView) {
        final int firstListItemPosition = listView.getFirstVisiblePosition();
        final int lastListItemPosition =firstListItemPosition + listView.getChildCount() - 1;

        if (position < firstListItemPosition || position > lastListItemPosition ) {
            return listView.getAdapter().getView(position, listView.getChildAt(position), listView);
        } else {
            final int childIndex = position - firstListItemPosition;
            return listView.getChildAt(childIndex);
        }
    }
}
