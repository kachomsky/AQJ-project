package nucli.com.aquejugamos.DAOImplementation;

import java.sql.Connection;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import nucli.com.aquejugamos.DAO.JocTaulaDAO;
import nucli.com.aquejugamos.DAO.MysqlDAOFactory;
import nucli.com.aquejugamos.general.JocTaula;
import nucli.com.aquejugamos.test.MysqlDAOFactoryWithTestDB;

import java.sql.ResultSet;
import java.sql.SQLException;

public class JocTaulaDAOMysqlImp implements JocTaulaDAO{
	/** Logger **/
	private static Logger logger = LoggerFactory.getLogger(JocTaulaDAOMysqlImp.class);
	
	private List<JocTaula> llistaJocsTaula = new ArrayList<JocTaula>();
	private int databaseTest;
	public JocTaulaDAOMysqlImp() {};
	
	/** Constructor que se usara si queremos usar la base de datos de test **/
	public JocTaulaDAOMysqlImp(int databaseTest) {
		this.databaseTest = databaseTest;
	};
	
	public void carregarJocsTaula() {
		logger.debug("Cargando datos de juegos de mesa");
		Connection conn = null;
		if(databaseTest == 1) {
			conn = MysqlDAOFactoryWithTestDB.crearConexio();
		}else {
			conn = MysqlDAOFactory.crearConexio();
		}
		try {
		Statement stmt = conn.createStatement();
		ResultSet rs = stmt.executeQuery("SELECT J.idJuego, J.idCategoria, C.NombreCategoria, J.NombreJuego, J.Dificultad, J.Edad,J.Jugadores,J.Tiempo, T.Nombre, J.Descripcion, J.Valoracion, J.idTipo, J.Imagen FROM juego J, categoria C,tipo T WHERE J.idCategoria=C.idCategoria AND J.idTipo=T.idTipo AND C.idCategoria=1;");
		
		while(rs.next())
		{
			int idJuego=rs.getInt(1);
			int idCategoria=rs.getInt(2);
			String nombreCategoria = rs.getString(3);
			String nombreJuego=rs.getString(4);
			int dificultad = rs.getInt(5);
			int edat = rs.getInt(6);
			String numeroJugadores = rs.getString(7);
			String tiempo = rs.getString(8);
			String tipo = rs.getString(9);
			String descripcion = rs.getString(10);
			String valoracion = rs.getString(11);
			int idTipo =rs.getInt(12);
			String imagen = rs.getString(13);
			JocTaula joc = new JocTaula(idJuego,idCategoria,nombreCategoria,nombreJuego,dificultad,edat, numeroJugadores,tiempo, tipo, descripcion,valoracion,idTipo, imagen);
			llistaJocsTaula.add(joc);			
		}
		
		rs.close();
		stmt.close();
		}catch(SQLException e) {
			//TODO: log error sql
			logger.error("Error al cargar los juegos de mesa: " + e.getMessage());
		}
	}


	@Override
	public List<JocTaula> getLlistaJocsTaula() {
		// TODO Auto-generated method stub
		return this.llistaJocsTaula;
	}
}
