package nucli.com.aquejugamos.DAO;

import java.sql.Connection;
import java.sql.SQLException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import nucli.com.aquejugamos.DAOImplementation.JocAlternatiuDAOMysqlImp;
import nucli.com.aquejugamos.DAOImplementation.JocDAOMysqlImp;
import nucli.com.aquejugamos.DAOImplementation.JocTaulaDAOMysqlImp;
import nucli.com.aquejugamos.DAOImplementation.PartidaDAOMysqlImp;
import nucli.com.aquejugamos.DAOImplementation.UsuarioDAOMysqlImp;
import java.sql.DriverManager;
import com.mysql.jdbc.jdbc2.optional.MysqlDataSource;

/** Clase que implementa una conexion a base de datos Mysql **/

public class MysqlDAOFactory extends DAOFactory{

	/** Logger **/
	private static Logger logger = LoggerFactory.getLogger(MysqlDAOFactory.class);


	public MysqlDAOFactory() {};

	/** Usaremos este metodo cada vez que queramos una conexion de tipo mysql
	 *  Si queremos usar la conexion con base de datos le pasaremos un 1 como testOption, sino un 0
	 * **/

	public static Connection crearConexio() {
		Connection conn = null;
		MysqlDataSource dataSource;
		/*dataSource = new MysqlDataSource();
		dataSource.setUser("root");
		dataSource.setServerName("127.0.0.1");
		dataSource.setPassword("");
		dataSource.setDatabaseName("nuevaversion");*/
		/*dataSource = new MysqlDataSource();
		dataSource.setUser("root2");
		dataSource.setServerName("158.109.64.10");
		dataSource.setPortNumber(55044);
		dataSource.setPassword("laboratori123");
		dataSource.setDatabaseName("aqj");*/
		try {
			conn = DriverManager.getConnection("jdbc:mysql://158.109.64.10:55044/aqj?useSSL=false", "root2", "laboratori123");
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		return conn;

	}

	@Override
	public JocAlternatiuDAO getJocAlternatiuDAO() {
		return new JocAlternatiuDAOMysqlImp();
	}

	@Override
	public JocTaulaDAO getJocTaulaDAO() {
		return new JocTaulaDAOMysqlImp();
	}

	@Override
	public JocDAO getJocDAO() {
		return new JocDAOMysqlImp();
	}

	@Override
	public PartidaDAO getPartidaDAO() {
		return new PartidaDAOMysqlImp();
	}

	@Override
	public UsuarioDAO getUsuarioDAO() {
		return new UsuarioDAOMysqlImp();
	}


}
