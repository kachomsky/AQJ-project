package nucli.com.aquejugamos.general;

import nucli.com.aquejugamos.DAO.*;
import nucli.com.aquejugamos.DAOImplementation.*;
/*import nucli.com.aquejugamos.DAO.JocTaulaDAO;
import nucli.com.aquejugamos.DAO.PartidaDAO;
import nucli.com.aquejugamos.DAO.UsuarioDAO;
import nucli.com.aquejugamos.DAOImplementation.UsuarioDAOMysqlImp;*/
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.sql.SQLException;
import java.util.Scanner;


public class Main {
	/** Logger **/
	private static Logger logger = LoggerFactory.getLogger(UsuarioDAOMysqlImp.class);

	public static void main(String[] args) throws SQLException {

		logger.debug("**** NUEVA EJECUCI�N DEL PROGRAMA ***");
		DAOFactory mysqlFactory = DAOFactory.getDAOFactory(DAOFactory.MYSQL);
		UsuarioDAO usuariDAO = mysqlFactory.getUsuarioDAO();
		JocAlternatiuDAO jocAlternatiuDAO = mysqlFactory.getJocAlternatiuDAO();
		JocTaulaDAO jocTaulaDAO = mysqlFactory.getJocTaulaDAO();
		PartidaDAO partidaDAO = mysqlFactory.getPartidaDAO();
		JocDAO jocDAO = mysqlFactory.getJocDAO();

		//jocDAO.mostrarJocs();
		jocAlternatiuDAO.carregarJocsAlternatius();
		jocTaulaDAO.carregarJocsTaula();
		usuariDAO.carregarUsuaris();
		Scanner sn = new Scanner(System.in);
		boolean sortir = false;
		int opcio;

		while(!sortir)
		{
			System.out.println("1. Opcio registrarse");
			System.out.println("2. Opcio login");
			System.out.println("3. Opcio veure Dades Usuaris");
			System.out.println("4. Opcio llista Preferits");
			System.out.println("5. Opcio Afegir pujar partida");
			System.out.println("6. Opcio Mostrar Partides Usuari");
			System.out.println("7. Opcio Logout");
			System.out.println("8. Opcio Agregar Amics");
			System.out.println("9. Opcio Mostrar Amics");
			System.out.println("10. Opcio Buscar Amics");
			System.out.println("11. Cerca avançada");
			System.out.println("12. Opcio Sortir");
			System.out.println("Selecciona la opcio a testejar");
			opcio = sn.nextInt();
			switch (opcio) {
				case 1:
					System.out.println("Has seleccionat registrarse");
					registrarse(usuariDAO);
					usuariDAO.carregarUsuaris();
					break;
				case 2:
					System.out.println("Has seleccionat fer login");
					login(usuariDAO);
					break;
				case 3:
					System.out.println("Has seleccionat consultarDadesUsuari");
					usuariDAO.consultaDadesUsuari();
					break;
				case 4:
					System.out.println("Has seleccionat afegirLlistaPreferits");
					addToListaJuegosUsuario(usuariDAO);
					break;
				case 5:
					System.out.println("Has seleccionat pujarPartida");
					pujarPartida(partidaDAO, usuariDAO);
					break;
				case 6:
					System.out.println("Has seleccionat mostrar partides Usuari");
					mostrarPartides(usuariDAO,partidaDAO);
					break;
				case 7:
					System.out.println("Has seleccionat logout");
					logout(usuariDAO);
					break;
				case 8:
					System.out.println("Has seleccionat Agregar amics");
					addFriend(usuariDAO);
					break;
				case 9:
					System.out.println("Has seleccionat Mostrar amics");
					mostrarAmics(usuariDAO);
					break;
				case 10:
					System.out.println("Has seleccionat buscar amics");
					buscarAmics(usuariDAO);
					break;
				case 11:
					System.out.println("Has seleccionat cerca avançada");
					busquedaAvanzada(jocDAO);
					break;
				case 12:
					sortir = true;
					System.exit(0);
					break;
				default:
					System.out.println("Numero entre 1 i 12");
			}
		}

	}

	public static void busquedaAvanzada(JocDAO jocDAO) {

		Scanner lector = new Scanner(System.in);

		String nom=null;
		String categoria=null;
		String nJugadors=null;
		String temps=null;
		String genere=null;

		System.out.println("*********");




		System.out.println("Introduce el campo o presiona ENTER para dejarlo vacio");

		System.out.print("Introduce el nombre del juego: ");
		nom = lector.nextLine();
		System.out.print("Categoria: ");
		categoria = lector.nextLine();
		System.out.print("nºjugadores: ");
		nJugadors = lector.nextLine();
		System.out.print("Tiempo de juego: ");
		temps = lector.nextLine();
		System.out.print("tipo: ");
		genere = lector.nextLine();
		System.out.println("*********");

		jocDAO.busquedaAvanzada(nom, nJugadors , temps , categoria , genere);
	}


	public static void registrarse(UsuarioDAO bd) throws SQLException
	{

		boolean nicknameValidat = false;
		int contador = 0;
		if(bd.comprovarUsuariLogejat())
		{
			System.out.println("Esta logejat per tant no es pot registrar fins que tanqui sessio");
		}
		else
		{
			Scanner lector = new Scanner(System.in);
			System.out.println("Inserta el nom d'usuari");
			String nomUsuari = lector.next();
			System.out.println(nomUsuari);
			System.out.println("Inserta el teu nickname ha de ser �nic!");
			String nickname = lector.next();
			while(!nicknameValidat)
			{
				for(Usuari u: bd.getLlistaUsuaris())
				{
					if(u.getNickname().equals(nickname))
					{
						System.out.println("Nickname repetit, introdueix un de nou");
						nickname = lector.next();
					}
					else
					{
						contador++;
						if(contador == bd.getLlistaUsuaris().size())
						{
							nicknameValidat = true;
						}
					}
				}
			}
			System.out.println("Inserta contrasenya");
			String password = lector.next();
			System.out.println("*********");
			System.out.println("Inserta e-mail");
			String mail = lector.next();
			System.out.println(mail);
			System.out.println("Inserta fecha Nacimiento");
			String fechaNacimiento = lector.next();
			System.out.println("Inserta Provincia");
			String provincia = lector.next();
			System.out.println("Inserta el grupo");
			String grupo = lector.next();

			Usuari u = new Usuari(0, nomUsuari, password, mail, 1, 0, 0, grupo, fechaNacimiento, provincia,nickname);
			bd.insertarUsuari(u);
		}
	}

	public static void login(UsuarioDAO bd) throws SQLException
	{
		boolean login = false;
		Scanner lector = new Scanner(System.in);
		System.out.println("Inserta e-mail");
		String mail = lector.next();
		System.out.println("Inserta el password");
		String password = lector.next();
		if(bd.comprovarUsuariLogejat())
		{
			System.out.println("Esta logejat per tant no es pot fer login fins que tanqui sessio");
		}
		else
		{
			login = bd.comprobarUsuari(mail,password);
			if (login)
			{
				System.out.println("Estas dins");
				bd.carregarAmicsUsuari();
			}
			else
			{
				System.out.println("Camps incorrectes");
			}
		}
	}

	public static void addToListaJuegosUsuario(UsuarioDAO bd) {
		Scanner lector = new Scanner(System.in);
		System.out.println("*********");
		//Aqui se tendria que buscar la id o se extrae en android una vez se printa la lista de juegos.
		System.out.println("Inserta la id del joc:");
		int idJoc = lector.nextInt();
		int idUsuari =0;
		if(bd.comprovarUsuariLogejat())
		{
			for(Usuari usuari : bd.getLlistaUsuaris())
			{
				System.out.println("*******");
				System.out.println(usuari.getNomUsuari());
				System.out.println("*******");
				if(usuari.getLogejat())
				{
					idUsuari = usuari.getIdUsuari();
				}
			}

			System.out.println("*********");

			bd.afegirLlistaPreferits(idJoc, idUsuari);
		}
		else
		{
			System.out.println("No logejat per tant no es pot afegir a favorits");
		}

	}

	public static void pujarPartida(PartidaDAO daoPartida, UsuarioDAO daoUser) throws SQLException
	{
		Scanner lector = new Scanner(System.in);
		System.out.println("Selecciona inserta el joc que vols pujar Partida");
		int idJoc = lector.nextInt();
		System.out.println("Inserta la duracio");
		int duracio = lector.nextInt();
		System.out.println("Inserta la data");
		String data = lector.next();
		System.out.println("Inserta nombre Juego");
		String nombre = lector.next();
		System.out.println("Inserta Numero Jugadores");
		int numero = lector.nextInt();
		System.out.println("Inserta quien ha ganado");
		String ganador = lector.next();
		System.out.println("Inserta un comentario");
		String comentario = lector.next();

		/*for (int i = 0; i < numero; i++) {
			System.out.println("Inserta el nombre del usuario " + i);
			//buscar usuario
			//insertar en participants de partida
		}*/

		//Usuari u = new Usuari(1, "nom", "pass", "main", 1, 0 , 0 , "UAB", "02-02-2012", "Barcelona", "Jordi");
		//Usuari u2 = new Usuari(2, "nom", "pass", "main", 1, 0 , 0 , "UAB", "02-02-2012", "Barcelona", "Pepe");
		int idParticipante;
		Partida p = new Partida(0, idJoc, duracio, data, numero, ganador, comentario);
		for(int i = 0; i < numero; i++) {
			System.out.println("Inserta el id del jugador "+i);
			idParticipante = lector.nextInt();
			Usuari uParticipant = daoUser.buscarUsuarioPorId(idParticipante);
			System.out.println("datosuser");
			System.out.println(uParticipant.getIdUsuari());
			System.out.println(uParticipant.getNickname());
			p.afegirParticipant(uParticipant);
		}

		for(Usuari u : p.getParticipants()) {
			System.out.println("usuario participante: " +u.getIdUsuari());
		}

		int idUsuari =0;
		if(daoUser.comprovarUsuariLogejat())
			try {
				{
					for(Usuari usuari : daoUser.getLlistaUsuaris())
					{
						if(usuari.getLogejat())
						{
							idUsuari = usuari.getIdUsuari();
						}
					}
					logger.debug("Subiendo partida");
				//	daoPartida.pujarPartida(p);
					logger.debug("Despues de subir partida");
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		else
		{
			System.out.println("No es pot pujar Partida");
		}


	}

	public static void addFriend(UsuarioDAO bd) throws SQLException
	{
		boolean agregat = false;
		System.out.println("Inserta el mail de la persona a agregar");
		Scanner lector = new Scanner(System.in);
		String email = lector.next();
		int idUsuariLogejat = 0;
		int idUsuariAgregar = 0;
		if(bd.comprovarUsuariLogejat())
		{
			for (Usuari usuari : bd.getLlistaUsuaris())
			{
				if(usuari.getLogejat())
				{
					idUsuariLogejat = usuari.getIdUsuari();
				}

				if(usuari.getMail().equals(email))
				{
					idUsuariAgregar = usuari.getIdUsuari();
					//System.out.println("Correcte");
				}
			}

			if(idUsuariLogejat != idUsuariAgregar)
			{
				agregat = bd.agregarAmic(idUsuariLogejat,idUsuariAgregar);
				if(agregat)
				{
					bd.carregarAmicsUsuari();
				}
			}

			else
			{
				System.out.println("No et pots agregar a tu mateix");
			}
		}
		else
		{
			System.out.println("No hi ha usuari logejat per tant no es pot agregar a amics");
		}

		if(agregat)
		{
			System.out.println("Ja souu amics !!!");
		}


	}

	public static void mostrarAmics(UsuarioDAO bd)
	{
		String amics="";
		if(bd.comprovarUsuariLogejat())
		{
			for (Integer i : bd.getLlistaIdUsuaris())
			{
				for(Usuari u: bd.getLlistaUsuaris())
				{
					if(i == u.getIdUsuari())
					{
						amics +=u.getNomUsuari()+"\n";
					}
				}
			}
			System.out.print(amics);
		}
		else
		{
			System.out.println("No logejat sorry");
		}
	}

	public static void buscarAmics(UsuarioDAO bd) throws SQLException
	{
		if(bd.comprovarUsuariLogejat())
		{
			System.out.println("Inserta el nom Usuari de la persona que vols buscar");
			Scanner lector = new Scanner(System.in);
			String nom = lector.next();
			nom = nom.toLowerCase();
			int tamanyNomEntrada = nom.length();
			boolean existeix = false;

			String nomCerca;
			for (Usuari u:bd.getLlistaUsuaris())
			{
				nomCerca = u.getNomUsuari().toLowerCase();
				if(nomCerca.length() > tamanyNomEntrada)
				{
					nomCerca = nomCerca.substring(0,tamanyNomEntrada);
				}
				//System.out.println(nom);
				//System.out.println(nomCerca);
				if(nom.equals(nomCerca))
				{
					System.out.println("Nom usuari: " + u.getNomUsuari());
					System.out.println("E-mail usuari: " + u.getMail());
					System.out.println("Si el vols agregar posa 1");
					int numero = lector.nextInt();
					if(numero == 1)
					{
						for(Usuari u1:bd.getLlistaUsuaris())
						{
							if(u1.getLogejat())
							{
								bd.agregarAmic(u1.getIdUsuari(), u.getIdUsuari());
							}
						}

					}
					existeix = true;
				}

			}

			if(!existeix)
			{
				System.out.println("No s'han trovat resultat");
			}
			bd.carregarAmicsUsuari();
		}
		else
		{
			System.out.println("No logejat");
		}
	}
	public static void mostrarPartides(UsuarioDAO bd,PartidaDAO partidaDAO) throws SQLException
	{
		int idUsuariLogejat;
		if(bd.comprovarUsuariLogejat())
		{
			for (Usuari usuari : bd.getLlistaUsuaris())
			{
				if(usuari.getLogejat())
				{
					idUsuariLogejat = usuari.getIdUsuari();
					partidaDAO.mostrarPartidesUsuari(idUsuariLogejat);

				}

			}
		}
	}
	public static void logout(UsuarioDAO bd)
	{
		if(bd.comprovarUsuariLogejat())
		{
			bd.logout();
		}

		else
		{
			System.out.println("No hi ha usuari logejat per tant no es pot deslogejar");
		}
	}


}

	

