package nucli.com.aquejugamos.DAOImplementation;

import android.util.Log;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import nucli.com.aquejugamos.DAO.DAOFactory;
import nucli.com.aquejugamos.DAO.MysqlDAOFactory;
import nucli.com.aquejugamos.DAO.UsuarioDAO;
import nucli.com.aquejugamos.general.Joc;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;

import nucli.com.aquejugamos.general.Usuari;
import nucli.com.aquejugamos.test.MysqlDAOFactoryWithTestDB;

public class UsuarioDAOMysqlImp implements UsuarioDAO{

	/** Logger **/
	private static Logger logger = LoggerFactory.getLogger(UsuarioDAOMysqlImp.class);

	private List<Usuari> llistaUsuaris = new ArrayList<Usuari>();
	private List<Integer> llistaIdAmics = new ArrayList<Integer>();

	private int databaseTest;
	public UsuarioDAOMysqlImp() {};

	/** Constructor que se usara si queremos usar la base de datos de test **/
	public UsuarioDAOMysqlImp(int databaseTest) {
		this.databaseTest = databaseTest;
	};

	public void carregarUsuaris() {
		Connection conn = null;
		if(databaseTest == 1) {
			conn = MysqlDAOFactoryWithTestDB.crearConexio();
		}else {
			conn = MysqlDAOFactory.crearConexio();
		}
		try {
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT U.idUsuario, U.Email, U.Nombre, U.password, U.Activo, U.Bloqueado,U.isAdmin,U.Grupo,U.Fecha,U.Provincia,U.nickname FROM usuario U;");

			while(rs.next())
			{
				int idUsuario=rs.getInt(1);
				String email=rs.getString(2);
				String nombre = rs.getString(3);
				String password=rs.getString(4);
				int activo = rs.getInt(5);
				int bloqueado = rs.getInt(6);
				int isAdmin = rs.getInt(7);
				String grupo = rs.getString(8);
				String fecha = rs.getString(9);
				String provincia = rs.getString(10);
				String nickname = rs.getString(11);
				Usuari usuari = new Usuari(idUsuario,nombre,password,email,activo,bloqueado, isAdmin,grupo,fecha,provincia,nickname);
				llistaUsuaris.add(usuari);
			}

			stmt.close();
			rs.close();

			logger.debug("Usuarios cargados");


			for(Usuari u : this.llistaUsuaris) {
				carregarLlistaFavoritsUser(u);
				mostrarLlistaPreferits(u);
			}
		}catch(SQLException e) {
			//TODO: log error
			logger.error("*** ERROR SQL AL CARGAR LOS DATOS DE USUARIO ***");
		}
	}

	public Usuari buscarUsuarioPorId(int idUser) {
		Connection conn = null;
		ResultSet usuario;
		Usuari u = null;
		if(databaseTest == 1) {
			conn = MysqlDAOFactoryWithTestDB.crearConexio();
		}else {
			conn = MysqlDAOFactory.crearConexio();
		}
		try{
			Statement stmt = conn.createStatement();
			String queryStr = "SELECT U.idUsuario, U.Email, U.Nombre, U.password, U.Activo, U.Bloqueado,U.isAdmin,U.Grupo,U.Fecha,U.Provincia,U.nickname FROM usuario U WHERE idUsuario = ?;";
			PreparedStatement pstmt = conn.prepareStatement(queryStr);
			pstmt.setInt(1, idUser);
			usuario = pstmt.executeQuery();
			while(usuario.next())
			{
				int idUsuario=usuario.getInt(1);
				String email=usuario.getString(2);
				String nombre = usuario.getString(3);
				String password=usuario.getString(4);
				int activo = usuario.getInt(5);
				int bloqueado = usuario.getInt(6);
				int isAdmin = usuario.getInt(7);
				String grupo = usuario.getString(8);
				String fecha = usuario.getString(9);
				String provincia = usuario.getString(10);
				String nickname = usuario.getString(11);
				u = new Usuari(idUsuario,nombre,password,email,activo,bloqueado, isAdmin,grupo,fecha,provincia,nickname);
			}

			stmt.close();
			usuario.close();
		}catch(SQLException e) {
			//TODO: log error
			logger.error("*** ERROR SQL AL CARGAR LOS DATOS DE USUARIO ***" + e.getMessage());
		}

		return u;
	}

	public Usuari buscarUsuarioPorNickname(String nicknameBusqueda) {
		Connection conn = null;
		ResultSet usuario;
		Usuari u = null;
		if(databaseTest == 1) {
			conn = MysqlDAOFactoryWithTestDB.crearConexio();
		}else {
			conn = MysqlDAOFactory.crearConexio();
		}
		try{
			Statement stmt = conn.createStatement();
			String queryStr = "SELECT U.idUsuario, U.Email, U.Nombre, U.password, U.Activo, U.Bloqueado,U.isAdmin,U.Grupo,U.Fecha,U.Provincia,U.nickname FROM usuario U WHERE nickname = ?;";
			PreparedStatement pstmt = conn.prepareStatement(queryStr);
			pstmt.setString(1, nicknameBusqueda);
			usuario = pstmt.executeQuery();
			while(usuario.next())
			{
				int idUsuario=usuario.getInt(1);
				String email=usuario.getString(2);
				String nombre = usuario.getString(3);
				String password=usuario.getString(4);
				int activo = usuario.getInt(5);
				int bloqueado = usuario.getInt(6);
				int isAdmin = usuario.getInt(7);
				String grupo = usuario.getString(8);
				String fecha = usuario.getString(9);
				String provincia = usuario.getString(10);
				String nickname = usuario.getString(11);
				u = new Usuari(idUsuario,nombre,password,email,activo,bloqueado, isAdmin,grupo,fecha,provincia,nickname);
			}

			stmt.close();
			usuario.close();
		}catch(SQLException e) {
			//TODO: log error
			logger.error("*** ERROR SQL AL CARGAR LOS DATOS DE USUARIO ***" + e.getMessage());
		}

		return u;
	}

	public Usuari loginUsuari(String email, String password){
		Connection conn = null;
		ResultSet usuario;
		Usuari u = null;
		if(databaseTest == 1) {
			conn = MysqlDAOFactoryWithTestDB.crearConexio();
		}else {
			conn = MysqlDAOFactory.crearConexio();
		}
		try{
			Statement stmt = conn.createStatement();
			String queryStr = "SELECT U.idUsuario, U.Email, U.Nombre, U.password, U.Activo, U.Bloqueado,U.isAdmin,U.Grupo,U.Fecha,U.Provincia,U.nickname FROM usuario U WHERE Email = ?;";
			PreparedStatement pstmt = conn.prepareStatement(queryStr);
			pstmt.setString(1, email);
			usuario = pstmt.executeQuery();
			while(usuario.next())
			{
				int idUsuario=usuario.getInt(1);
				String emailbd=usuario.getString(2);
				String nombre = usuario.getString(3);
				String passwordbd=usuario.getString(4);
				int activo = usuario.getInt(5);
				int bloqueado = usuario.getInt(6);
				int isAdmin = usuario.getInt(7);
				String grupo = usuario.getString(8);
				String fecha = usuario.getString(9);
				String provincia = usuario.getString(10);
				String nickname = usuario.getString(11);

				if(passwordbd.equals(password)) {
					u = new Usuari(idUsuario, nombre, passwordbd, emailbd, activo, bloqueado, isAdmin, grupo, fecha, provincia, nickname);
				}
			}

			stmt.close();
			usuario.close();
		}catch(SQLException e) {
			//TODO: log error
			logger.error("*** ERROR SQL AL CARGAR LOS DATOS DE USUARIO ***" + e.getMessage());
		}

		return u;
	}

	private void mostrarLlistaPreferits(Usuari u) throws SQLException {
		for(Joc j:u.getLlistaJocs()) {
			System.out.println(j.getNomJoc());
		}
	}

	public ArrayList<Joc> carregarLlistaFavoritsUser(Usuari u) throws SQLException {
		ResultSet rsListaJuegos;
		ArrayList<Joc> jocs = new ArrayList<>();
		String queryStr = "SELECT DISTINCT NombreJuego, Dificultad, Edad, Jugadores, Descripcion, Tiempo, Valoracion, Materiales, idTipo, idCategoria, j.idJuego, j.Imagen FROM juego j, usuario u, juegosusuario ju WHERE j.idJuego = ju.idJuego AND u.idUsuario = u.idUsuario AND ju.idUsuario = ?;";
		Connection conn = null;
		if(databaseTest == 1) {
			conn = MysqlDAOFactoryWithTestDB.crearConexio();
		}else {
			conn = MysqlDAOFactory.crearConexio();
		}
		PreparedStatement pstmt = conn.prepareStatement(queryStr);
		pstmt.setInt(1, u.getIdUsuari());
		rsListaJuegos = pstmt.executeQuery();

		while(rsListaJuegos.next()) {
			String nombreJuego = rsListaJuegos.getString(1);
			int dificultad = rsListaJuegos.getInt(2);
			int edad = rsListaJuegos.getInt(3);
			String jugadores = rsListaJuegos.getString(4);
			String descripcion = rsListaJuegos.getString(5);
			String tiempo = rsListaJuegos.getString(6);
			String valoracion = rsListaJuegos.getString(7);
			String materiales = rsListaJuegos.getString(8);
			int idTipo = rsListaJuegos.getInt(9);
			int idCategoria = rsListaJuegos.getInt(10);
			int idJuego = rsListaJuegos.getInt(11);
			String imagen = rsListaJuegos.getString(12);

			Joc jocLista = new Joc(idJuego, idCategoria, "categoria", nombreJuego, dificultad, edad,
					jugadores, tiempo, "tipo", descripcion, valoracion, idTipo,
					imagen);
			jocs.add(jocLista);
		}

		pstmt.close();
		return jocs;
	}

	public boolean comprobarUsuari(String mail, String password)
	{
		boolean estaRegistrat = false;
		for (Usuari u:this.llistaUsuaris)
		{
			if(u.getMail().equals(mail))
			{
				System.out.println(u.getMail());
				System.out.println(u.getPassword());
				if(u.getPassword().equals(password))
				{

					estaRegistrat = true;
					u.setLogejat(true);
				}
			}
		}
		return estaRegistrat;
	}

	public boolean afegirLlistaPreferits(int idJoc, int idUsuari)
	{
		logger.debug("Anadiendo juego a lista de favoritos de usuario" + idUsuari);
		int affectedRows = 0;
		boolean anadido = false;
		try {
			Connection conn = null;
			if(databaseTest == 1) {
				conn = MysqlDAOFactoryWithTestDB.crearConexio();
			}else {
				conn = MysqlDAOFactory.crearConexio();
			}
			PreparedStatement pstmt = conn.prepareStatement("INSERT INTO juegosusuario (idJuego, idUsuario) VALUES(?,?);");
			pstmt.setInt(1, idJoc);
			pstmt.setInt(2, idUsuari);
			affectedRows = pstmt.executeUpdate();

			if(affectedRows == 0) {
				logger.error("No se ha podido anadir a favoritos el juego con id " + idJoc + " en el usuario con id "+ idUsuari);
			}else {
				anadido = true;
				logger.info("Se ha insertado a favoritos correctamente");
			}
			pstmt.close();

		} catch (SQLException e) {
			logger.error("No se ha podido anadir a favoritos el juego con id " + idJoc + " en el usuario con id "
					+ idUsuari + "\n El error ha sido " + e.getMessage());
		}

		return anadido;
	}

	public void consultaDadesUsuari()
	{
		for (Usuari user: this.llistaUsuaris)
		{
			if(user.getLogejat())
			{
				System.out.println(user.getIdUsuari() + " " + user.getNomUsuari() +" " + user.getMail() + " " + user.getGrupo()+ " "+user.getFecha() + " " + user.getProvincia());
			}
			else
			{
				System.out.println("No estas logejat");
			}

		}
	}


	public boolean comprovarUsuariLogejat()
	{
		boolean logejat = false;
		for(Usuari u:this.llistaUsuaris)
		{
			if(u.getLogejat())
			{
				System.out.println("Esta logejat si!!\n");
				System.out.println(u.getMail());
				logejat = true;

			}
			else
			{
				System.out.println("No logejat\n");
			}
		}
		return logejat;
	}

	public boolean logout()
	{
		boolean logout = false;
		for(Usuari u:this.llistaUsuaris)
		{
			if(u.getLogejat())
			{
				u.setLogejat(false);
				logout = true;
			}
			else
			{
				logger.error("Error al deslogejar");
			}
		}
		return logout;
	}

	public Map validarRegistro(Usuari u){
		Map<String, Boolean> camposValidados = new HashMap<String, Boolean>();

		//VALIDANDO EMAIL
		String emailRegularExpresion = "(?:(?:\\r\\n)?[ \\t])*(?:(?:(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\"(?:[^\\\"\\r\\\\]|\\\\.|(?:(?:\\r\\n)?[ \\t]))*\"(?:(?:\\r\\n)?[ \\t])*)(?:\\.(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\"(?:[^\\\"\\r\\\\]|\\\\.|(?:(?:\\r\\n)?[ \\t]))*\"(?:(?:\\r\\n)?[ \\t])*))*@(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\\[([^\\[\\]\\r\\\\]|\\\\.)*\\](?:(?:\\r\\n)?[ \\t])*)(?:\\.(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\\[([^\\[\\]\\r\\\\]|\\\\.)*\\](?:(?:\\r\\n)?[ \\t])*))*|(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\"(?:[^\\\"\\r\\\\]|\\\\.|(?:(?:\\r\\n)?[ \\t]))*\"(?:(?:\\r\\n)?[ \\t])*)*\\<(?:(?:\\r\\n)?[ \\t])*(?:@(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\\[([^\\[\\]\\r\\\\]|\\\\.)*\\](?:(?:\\r\\n)?[ \\t])*)(?:\\.(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\\[([^\\[\\]\\r\\\\]|\\\\.)*\\](?:(?:\\r\\n)?[ \\t])*))*(?:,@(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\\[([^\\[\\]\\r\\\\]|\\\\.)*\\](?:(?:\\r\\n)?[ \\t])*)(?:\\.(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\\[([^\\[\\]\\r\\\\]|\\\\.)*\\](?:(?:\\r\\n)?[ \\t])*))*)*:(?:(?:\\r\\n)?[ \\t])*)?(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\"(?:[^\\\"\\r\\\\]|\\\\.|(?:(?:\\r\\n)?[ \\t]))*\"(?:(?:\\r\\n)?[ \\t])*)(?:\\.(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\"(?:[^\\\"\\r\\\\]|\\\\.|(?:(?:\\r\\n)?[ \\t]))*\"(?:(?:\\r\\n)?[ \\t])*))*@(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\\[([^\\[\\]\\r\\\\]|\\\\.)*\\](?:(?:\\r\\n)?[ \\t])*)(?:\\.(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\\[([^\\[\\]\\r\\\\]|\\\\.)*\\](?:(?:\\r\\n)?[ \\t])*))*\\>(?:(?:\\r\\n)?[ \\t])*)|(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\"(?:[^\\\"\\r\\\\]|\\\\.|(?:(?:\\r\\n)?[ \\t]))*\"(?:(?:\\r\\n)?[ \\t])*)*:(?:(?:\\r\\n)?[ \\t])*(?:(?:(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\"(?:[^\\\"\\r\\\\]|\\\\.|(?:(?:\\r\\n)?[ \\t]))*\"(?:(?:\\r\\n)?[ \\t])*)(?:\\.(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\"(?:[^\\\"\\r\\\\]|\\\\.|(?:(?:\\r\\n)?[ \\t]))*\"(?:(?:\\r\\n)?[ \\t])*))*@(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\\[([^\\[\\]\\r\\\\]|\\\\.)*\\](?:(?:\\r\\n)?[ \\t])*)(?:\\.(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\\[([^\\[\\]\\r\\\\]|\\\\.)*\\](?:(?:\\r\\n)?[ \\t])*))*|(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\"(?:[^\\\"\\r\\\\]|\\\\.|(?:(?:\\r\\n)?[ \\t]))*\"(?:(?:\\r\\n)?[ \\t])*)*\\<(?:(?:\\r\\n)?[ \\t])*(?:@(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\\[([^\\[\\]\\r\\\\]|\\\\.)*\\](?:(?:\\r\\n)?[ \\t])*)(?:\\.(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\\[([^\\[\\]\\r\\\\]|\\\\.)*\\](?:(?:\\r\\n)?[ \\t])*))*(?:,@(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\\[([^\\[\\]\\r\\\\]|\\\\.)*\\](?:(?:\\r\\n)?[ \\t])*)(?:\\.(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\\[([^\\[\\]\\r\\\\]|\\\\.)*\\](?:(?:\\r\\n)?[ \\t])*))*)*:(?:(?:\\r\\n)?[ \\t])*)?(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\"(?:[^\\\"\\r\\\\]|\\\\.|(?:(?:\\r\\n)?[ \\t]))*\"(?:(?:\\r\\n)?[ \\t])*)(?:\\.(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\"(?:[^\\\"\\r\\\\]|\\\\.|(?:(?:\\r\\n)?[ \\t]))*\"(?:(?:\\r\\n)?[ \\t])*))*@(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\\[([^\\[\\]\\r\\\\]|\\\\.)*\\](?:(?:\\r\\n)?[ \\t])*)(?:\\.(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\\[([^\\[\\]\\r\\\\]|\\\\.)*\\](?:(?:\\r\\n)?[ \\t])*))*\\>(?:(?:\\r\\n)?[ \\t])*)(?:,\\s*(?:(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\"(?:[^\\\"\\r\\\\]|\\\\.|(?:(?:\\r\\n)?[ \\t]))*\"(?:(?:\\r\\n)?[ \\t])*)(?:\\.(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\"(?:[^\\\"\\r\\\\]|\\\\.|(?:(?:\\r\\n)?[ \\t]))*\"(?:(?:\\r\\n)?[ \\t])*))*@(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\\[([^\\[\\]\\r\\\\]|\\\\.)*\\](?:(?:\\r\\n)?[ \\t])*)(?:\\.(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\\[([^\\[\\]\\r\\\\]|\\\\.)*\\](?:(?:\\r\\n)?[ \\t])*))*|(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\"(?:[^\\\"\\r\\\\]|\\\\.|(?:(?:\\r\\n)?[ \\t]))*\"(?:(?:\\r\\n)?[ \\t])*)*\\<(?:(?:\\r\\n)?[ \\t])*(?:@(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\\[([^\\[\\]\\r\\\\]|\\\\.)*\\](?:(?:\\r\\n)?[ \\t])*)(?:\\.(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\\[([^\\[\\]\\r\\\\]|\\\\.)*\\](?:(?:\\r\\n)?[ \\t])*))*(?:,@(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\\[([^\\[\\]\\r\\\\]|\\\\.)*\\](?:(?:\\r\\n)?[ \\t])*)(?:\\.(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\\[([^\\[\\]\\r\\\\]|\\\\.)*\\](?:(?:\\r\\n)?[ \\t])*))*)*:(?:(?:\\r\\n)?[ \\t])*)?(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\"(?:[^\\\"\\r\\\\]|\\\\.|(?:(?:\\r\\n)?[ \\t]))*\"(?:(?:\\r\\n)?[ \\t])*)(?:\\.(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\"(?:[^\\\"\\r\\\\]|\\\\.|(?:(?:\\r\\n)?[ \\t]))*\"(?:(?:\\r\\n)?[ \\t])*))*@(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\\[([^\\[\\]\\r\\\\]|\\\\.)*\\](?:(?:\\r\\n)?[ \\t])*)(?:\\.(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\\[([^\\[\\]\\r\\\\]|\\\\.)*\\](?:(?:\\r\\n)?[ \\t])*))*\\>(?:(?:\\r\\n)?[ \\t])*))*)?;\\s*)";
		Pattern ptr = Pattern.compile(emailRegularExpresion);
		boolean emailCorrecto = ptr.matcher(u.getMail()).matches();
		camposValidados.put("email", emailCorrecto);

		//VALIDANDO NOMBRE
		String nombreRegularExpresion = "^[\\p{L} .'-]+$";
		ptr = Pattern.compile(nombreRegularExpresion);
		boolean nombreCorrecto = ptr.matcher(u.getNomUsuari()).matches();
		camposValidados.put("nombre", nombreCorrecto);

		//VALIDANDO NICKNAME
		/*String nicknameRegularExpresion= "(?=.*[^ ])[a-zA-Z0-9 ]+";
		ptr = Pattern.compile(nicknameRegularExpresion);
		boolean nicknameCorrecto = ptr.matcher(u.getNickname()).matches();*/
		boolean nicknameCorrecto = false;
		if(u.getNickname().length() > 0){
			nicknameCorrecto = true;
		}
		camposValidados.put("nickname", nicknameCorrecto);

		//VALIDANDO FECHA
		boolean fechaCorrecto;
		SimpleDateFormat fecha = new SimpleDateFormat("dd-MM-yyyy");

		try{
			fecha.parse(u.getFecha());
			fechaCorrecto = true;
		}catch(Exception e){
			fechaCorrecto = false;
		}

		camposValidados.put("fecha", fechaCorrecto);

		//VALIDANDO CIUDAD
		String ciudadRegularExpresion = "^[\\p{L} .'-]+$";
		ptr = Pattern.compile(ciudadRegularExpresion);
		boolean ciudadCorrecto = ptr.matcher(u.getProvincia()).matches();
		camposValidados.put("ciudad", ciudadCorrecto);

		//VALIDANDO PASSWORD
		boolean passwordCorrecto = true;

		if(u.getPassword().length() < 8){
			passwordCorrecto = false;
		}

		camposValidados.put("password", passwordCorrecto);

		return camposValidados;
	}

	public boolean insertarUsuari(Usuari u) {

		logger.debug("Insertando usuario");
		boolean insertCorrecto = false;
		int affectedRows = 0;
		Connection conn = null;
		if(databaseTest == 1) {
			conn = MysqlDAOFactoryWithTestDB.crearConexio();
		}else {
			conn = MysqlDAOFactory.crearConexio();
		}

		Map<String, Boolean> camposValidados = validarRegistro(u);
		if(camposValidados.get("email") && camposValidados.get("nombre")
				&& camposValidados.get("nickname") && camposValidados.get("fecha")
				&& camposValidados.get("ciudad") && camposValidados.get("password"))
		{
			try {

				PreparedStatement pstmt = conn.prepareStatement("INSERT INTO usuario (Email,Nombre,Password,Activo,Bloqueado,isAdmin,Grupo,Fecha,Provincia,nickname) VALUES (?,?,?,?,?,?,?,?,?,?)");
				pstmt.setString(1,u.getMail());
				pstmt.setString(2,u.getNomUsuari());
				pstmt.setString(3,u.getPassword());
				pstmt.setInt(4,u.getActivo());
				pstmt.setInt(5,u.getBloqueado());
				pstmt.setInt(6,u.getIsAdmin());
				pstmt.setString(7,u.getGrupo());
				pstmt.setString(8,u.getFecha());
				pstmt.setString(9, u.getProvincia());
				pstmt.setString(10, u.getNickname());
				affectedRows = pstmt.executeUpdate();
				pstmt.close();

				if(affectedRows == 0) {
					logger.error("No se ha modificado ninguna fila al insertar. Fallido.");
					logger.error("Ha surgido un error al intentar insertar el usuario: \n "
							+ "**User**\n" + u.getMail()+"\n"+u.getNomUsuari()+"\n"+u.getPassword()
							+"\n"+u.getActivo()+"\n"+u.getBloqueado()+"\n"+u.getIsAdmin()+"\n"+u.getGrupo()
							+"\n"+u.getFecha()+"\n"+u.getProvincia()+"\n" + u.getNickname()+"\n");
					//throw new SQLException("El registro del usuario ha fallado");
				}else {
					insertCorrecto = true;
					logger.info("Usuario insertado correctamente: \n "
							+ "**User**\n" + u.getMail()+"\n"+u.getNomUsuari()+"\n"+u.getPassword()
							+"\n"+u.getActivo()+"\n"+u.getBloqueado()+"\n"+u.getIsAdmin()+"\n"+u.getGrupo()
							+"\n"+u.getFecha()+"\n"+u.getProvincia()+"\n"+u.getNickname()+"\n");
				}
			}catch(SQLException e) {
				//TODO: log error

				logger.error("Ha surgido un error al intentar insertar el usuario: "+e.getMessage()+"\n "
						+ "**User**\n" + u.getMail()+"\n"+u.getNomUsuari()+"\n"+u.getPassword()
						+"\n"+u.getActivo()+"\n"+u.getBloqueado()+"\n"+u.getIsAdmin()+"\n"+u.getGrupo()
						+"\n"+u.getFecha()+"\n"+u.getProvincia()+"\n"+u.getNickname()+"\n");
			}
		}
		else
		{
			for (Map.Entry<String, Boolean> entry : camposValidados.entrySet())
			{
				if(!entry.getValue().booleanValue()){
					System.out.println();
					Log.e("REGISTRO","Valor incorrecto en " + entry.getKey());
				}
			}

		}
		return insertCorrecto;

	}

	public boolean agregarAmic(int idUsuariLogejat,int idUsuariAgregar)
	{
		boolean agregat = false;
		Connection conn = null;
		if(databaseTest == 1) {
			conn = MysqlDAOFactoryWithTestDB.crearConexio();
		}else {
			conn = MysqlDAOFactory.crearConexio();
		}
		PreparedStatement pstmt;
		try {
			pstmt = conn.prepareStatement("INSERT INTO lista_amigos (idUsuario1, idUsuario2) VALUES(?,?);");
			pstmt.setInt(1, idUsuariLogejat);
			pstmt.setInt(2, idUsuariAgregar);
			pstmt.executeUpdate();
			pstmt.close();
			agregat = true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


		return agregat;
	}


	public void carregarAmicsUsuari() throws SQLException
	{
		Usuari usuari = null;
		boolean cargarLlista = false;
		for (Usuari u: this.llistaUsuaris){
			if(u.getLogejat())
			{
				usuari = u;
				cargarLlista = true;
			}
		}

		if(cargarLlista)
		{
			Connection conn = null;
			if(databaseTest == 1) {
				conn = MysqlDAOFactoryWithTestDB.crearConexio();
			}else {
				conn = MysqlDAOFactory.crearConexio();
			}

			ResultSet rsLlistaIdAmics;
			String queryStr = "SELECT idUsuario2 FROM lista_amigos WHERE idUsuario1= ?;";
			PreparedStatement pstmt = conn.prepareStatement(queryStr);
			pstmt.setInt(1, usuari.getIdUsuari());
			rsLlistaIdAmics = pstmt.executeQuery();
			while(rsLlistaIdAmics.next())
			{
				int idUsuario=rsLlistaIdAmics.getInt(1);
				this.llistaIdAmics.add(idUsuario);
			}

			pstmt.close();
			rsLlistaIdAmics.close();

			logger.debug("Id amics carregats");



		}

		else
		{
			System.out.println("No logejat el usuari per tant no es podem carregar Amics");
		}
	}

	public boolean eliminarUsuario(String email) {
		logger.debug("Eliminando usuario");
		boolean eliminado = false;
		int affectedRows = 0;
		Connection conn = null;
		if(databaseTest == 1) {
			conn = MysqlDAOFactoryWithTestDB.crearConexio();
		}else {
			conn = MysqlDAOFactory.crearConexio();
		}
		try {
			PreparedStatement pstmt = conn.prepareStatement("DELETE FROM usuario WHERE Email=?");
			pstmt.setString(1, email);
			affectedRows = pstmt.executeUpdate();
			pstmt.close();
			if(affectedRows == 0) {
				logger.error("Ha surgido un error al intentar eliminar el usuario con email: "+email+"\n");
			}else {
				eliminado = true;
				logger.info("El usuario con email "+email+" ha sido eliminado correctamente");
			}
		} catch (SQLException e) {
			logger.error("Ha surgido un error al intentar eliminar el usuario con email: "+email+"\n "
					+ "** Error **" + e.getMessage());
		}

		return eliminado;
	}

	public List<Integer> getLlistaIdUsuaris() {

		return this.llistaIdAmics;

	}

	@Override
	public List<Usuari> getLlistaUsuaris() {

		return this.llistaUsuaris;

	}

}
