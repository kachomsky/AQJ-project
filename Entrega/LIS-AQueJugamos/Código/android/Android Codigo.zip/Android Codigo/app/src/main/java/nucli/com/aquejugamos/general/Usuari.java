package nucli.com.aquejugamos.general;

import java.util.ArrayList;

public class Usuari {

	private int idUsuari;
	private String nomUsuari;
	private String password;
	private String mail;
	private int activo;
	private int bloqueado;
	private int isAdmin;
	private String grupo;
	private String fecha;
	private String provincia;
	private String nickname;
	private boolean logejat = false;
	private ArrayList<Joc> llistaJocs;

	public int getIdUsuari() {
		return idUsuari;
	}

	public void setIdUsuari(int idUsuari) {
		this.idUsuari = idUsuari;
	}

	public String getNomUsuari() {
		return nomUsuari;
	}

	public void setNomUsuari(String nomUsuari) {
		this.nomUsuari = nomUsuari;
	}

	public String getNickname() {
		return this.nickname;
	}

	public void setNickname(String nickname) {
		this.nickname = nickname;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getMail() {
		return mail;
	}

	public void setMail(String mail) {
		this.mail = mail;
	}

	public int getActivo() {
		return activo;
	}

	public void setActivo(int activo) {
		this.activo = activo;
	}

	public int getBloqueado() {
		return bloqueado;
	}

	public void setBloqueado(int bloqueado) {
		this.bloqueado = bloqueado;
	}

	public int getIsAdmin() {
		return isAdmin;
	}

	public void setIsAdmin(int isAdmin) {
		this.isAdmin = isAdmin;
	}

	public String getGrupo() {
		return grupo;
	}

	public void setGrupo(String grupo) {
		this.grupo = grupo;
	}

	public ArrayList<Joc> getLlistaJocs() {
		return this.llistaJocs;
	}

	public Usuari(int idUsuari, String nomUsuari, String password, String mail, int activo, int bloqueado, int isAdmin,
				  String grupo, String fecha, String provincia,String nickname) {
		super();
		this.idUsuari = idUsuari;
		this.nomUsuari = nomUsuari;
		this.password = password;
		this.mail = mail;
		this.activo = activo;
		this.bloqueado = bloqueado;
		this.isAdmin = isAdmin;
		this.grupo = grupo;
		this.llistaJocs = new ArrayList<Joc>();
		this.fecha = fecha;
		this.provincia = provincia;
		this.nickname = nickname;
	}

	public String getFecha() {
		return fecha;
	}

	public void setFecha(String fecha) {
		this.fecha = fecha;
	}

	public String getProvincia() {
		return provincia;
	}

	public void setProvincia(String provincia) {
		this.provincia = provincia;
	}

	public void addJocToUser(Joc jocSalonJuegos) {
		this.llistaJocs.add(jocSalonJuegos);
	}

	public boolean getLogejat() {
		return this.logejat;
	}

	public void setLogejat(boolean logejat) {
		this.logejat = logejat;
	}

}
