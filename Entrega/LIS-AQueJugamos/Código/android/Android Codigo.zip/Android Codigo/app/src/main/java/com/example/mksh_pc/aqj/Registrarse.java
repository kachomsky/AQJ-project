package com.example.mksh_pc.aqj;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import nucli.com.aquejugamos.DAO.DAOFactory;
import nucli.com.aquejugamos.DAO.UsuarioDAO;
import nucli.com.aquejugamos.general.Usuari;

public class Registrarse extends AppCompatActivity implements View.OnClickListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registrarse);
        Button registrar = (Button) findViewById(R.id.regEnviarBtn);
        registrar.setOnClickListener(this);
    }

    public void onClick(View view){
        switch(view.getId()) {
            case R.id.regEnviarBtn:
                registrar();
                break;
        }
    }

    private boolean registrar(){
        boolean registroCorrecto = false;
        EditText nombre = (EditText) findViewById(R.id.regNombreET);
        EditText pass = (EditText) findViewById(R.id.regContraseñaET);
        EditText email = (EditText) findViewById(R.id.regEmailET);
        EditText fechaNacimiento = (EditText) findViewById(R.id.regFechaET);
        EditText ciudad = (EditText) findViewById(R.id.regCiudadET);
        EditText nickname = (EditText) findViewById(R.id.regNicknameET);
        Usuari user = new Usuari(0, nombre.getText().toString(), pass.getText().toString(), email.getText().toString(), 1, 0, 0, "None", fechaNacimiento.getText().toString(), ciudad.getText().toString(),nickname.getText().toString());
        ExecutorService executor = Executors.newCachedThreadPool();
        Future<Boolean> registroSubmit = executor.submit(new Registrarse.registroBD(user));

        try{
            Log.d("El valor del registro es",Boolean.toString(registroSubmit.get()));
            if(registroSubmit.get()){
                registroCorrecto = true;
            }
        }catch(Exception e){
            Log.e("REGISTRO", "Error al recoger valores de objeto Future");
        }
        if(registroCorrecto){
            Log.i("REGISTRO", "El registro se ha completado exitosamente");
            Toast.makeText(Registrarse.this, "El registro se ha completado con éxito!", Toast.LENGTH_LONG).show();
            nombre.setTextColor(Color.BLACK);
            email.setTextColor(Color.BLACK);
            nickname.setTextColor(Color.BLACK);
            fechaNacimiento.setTextColor(Color.BLACK);
            pass.setTextColor(Color.BLACK);
            ciudad.setTextColor(Color.BLACK);
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        }else{

            Log.e("REGISTRO", "Ha habido un error a la hora de realizar el registro");
            Toast.makeText(Registrarse.this, "Por favor, rellena los campos correctamente", Toast.LENGTH_LONG).show();

            Future<Map> comprobarCampos = executor.submit(new Registrarse.comprobarCamposIncorrectosBD(user));

            try{
                Map<String, Boolean> camposValidados = comprobarCampos.get();

                if(!camposValidados.get("nombre")){
                    nombre.setTextColor(Color.RED);
                    nombre.setError("El nombre solo puede contener carácteres y espacios");
                }else{
                    nombre.setTextColor(Color.BLACK);
                }
                if(!camposValidados.get("email")){
                    email.setTextColor(Color.RED);
                    email.setError("Formato de correo inválido");
                }else{
                    email.setTextColor(Color.BLACK);
                }
                if(!camposValidados.get("nickname")){
                    nickname.setTextColor(Color.RED);
                    nickname.setError("El nickname no puede estar vacío");
                }else{
                    nickname.setTextColor(Color.BLACK);
                }
                if(!camposValidados.get("fecha")){
                    fechaNacimiento.setTextColor(Color.RED);
                    fechaNacimiento.setError("El formato de fecha debe ser: dd-mm-yyyy");
                }else {
                    fechaNacimiento.setTextColor(Color.BLACK);
                }
                if(!camposValidados.get("ciudad")){
                    ciudad.setTextColor(Color.RED);
                    ciudad.setError("La ciudad solo puede contener carácteres y espacios");
                }else{
                    ciudad.setTextColor(Color.BLACK);
                }
                if(!camposValidados.get("password")){
                    pass.setTextColor(Color.RED);
                    pass.setError("La contraseña debe contener almenos 8 carácteres");
                }else {
                    pass.setTextColor(Color.BLACK);
                }

            }catch (Exception e){
                Log.e("REGISTRO", "No se han podido obtener los campos validados");
            }
        }

        return registroCorrecto;
    }

    public class registroBD implements Callable<Boolean> {

        private Usuari user;

        public registroBD(Usuari user){
            this.user = user;
        }

        @Override
        public Boolean call() throws Exception {
            Boolean correcto = false;
            DAOFactory mysqlFactory = DAOFactory.getDAOFactory(DAOFactory.MYSQL);
            UsuarioDAO usuarioDAO = mysqlFactory.getUsuarioDAO();

            if(usuarioDAO.insertarUsuari(this.user)){
                correcto = true;
            }

            return correcto;
        }
    }

    public class comprobarCamposIncorrectosBD implements Callable<Map> {

        private Usuari user;

        public comprobarCamposIncorrectosBD(Usuari user){
            this.user = user;
        }

        @Override
        public Map call() throws Exception {

            Map<String, Boolean> camposValidados = new HashMap<String, Boolean>();
            DAOFactory mysqlFactory = DAOFactory.getDAOFactory(DAOFactory.MYSQL);
            UsuarioDAO usuarioDAO = mysqlFactory.getUsuarioDAO();
            camposValidados = usuarioDAO.validarRegistro(this.user);

            return camposValidados;
        }
    }
}
