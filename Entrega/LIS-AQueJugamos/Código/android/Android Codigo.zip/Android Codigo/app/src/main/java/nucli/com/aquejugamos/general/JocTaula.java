package nucli.com.aquejugamos.general;

public class JocTaula extends Joc{
	
	JocTaula()
	{
		
	}

	public JocTaula(int idJuego, int idCategoria, String nomCategoria, String nomJoc, int dificultat, int edat,
			String numeroJugadors, String duracio, String tipo, String descripcio, String valoracio, int idTipo,
			String imagen) {
		super(idJuego, idCategoria, nomCategoria, nomJoc, dificultat, edat, numeroJugadors, duracio, tipo, descripcio,
				valoracio, idTipo, imagen);
		// TODO Auto-generated constructor stub
	}

	
	
	
	
}
