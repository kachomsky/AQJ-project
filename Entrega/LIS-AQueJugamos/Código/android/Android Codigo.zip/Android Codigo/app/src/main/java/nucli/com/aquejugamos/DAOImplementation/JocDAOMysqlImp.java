package nucli.com.aquejugamos.DAOImplementation;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import nucli.com.aquejugamos.DAO.DAOFactory;
import nucli.com.aquejugamos.DAO.JocAlternatiuDAO;
import nucli.com.aquejugamos.DAO.JocDAO;
import nucli.com.aquejugamos.DAO.JocTaulaDAO;
import nucli.com.aquejugamos.DAO.MysqlDAOFactory;
import nucli.com.aquejugamos.general.Joc;
import nucli.com.aquejugamos.general.JocAlternatiu;
import nucli.com.aquejugamos.general.JocTaula;
import nucli.com.aquejugamos.general.Usuari;
import nucli.com.aquejugamos.test.MysqlDAOFactoryWithTestDB;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class JocDAOMysqlImp implements JocDAO{
	
	/** Logger **/
	private static Logger logger = LoggerFactory.getLogger(JocDAOMysqlImp.class);
	private int databaseTest;
	public JocDAOMysqlImp() {};
	
	/** Constructor que se usara si queremos usar la base de datos de test **/
	public JocDAOMysqlImp(int databaseTest) {
		this.databaseTest = databaseTest;
	};
	
	
	public void mostrarJocs(){
		
		System.out.println("Aquests son els jocs que tenim disponibles\n");
		Connection conn = null;
		if(databaseTest == 1) {
			conn = MysqlDAOFactoryWithTestDB.crearConexio();
		}else {
			conn = MysqlDAOFactory.crearConexio();
		}
		try {
		Statement stmt = conn.createStatement();
		ResultSet rs = stmt.executeQuery("SELECT J.idJuego, J.NombreJuego, J.Descripcion, J.Imagen, C.NombreCategoria FROM Juego J, Categoria C WHERE J.idCategoria=C.idCategoria");
		while(rs.next())
		{
			String nombre=rs.getString(1);
			String descripcion=rs.getString(2);
			String nombreCategoria=rs.getString(3);
			System.out.println(nombre + " " + descripcion+ " " + nombreCategoria);
		}
		
		rs.close();
		stmt.close();
		}catch(SQLException e) {
			//TODO: log error
		}
		
	}

	public ArrayList<String> getTodasCategorias(){
		logger.debug("Cargando datos de categorias");
		Connection conn = null;
		if(databaseTest == 1) {
			conn = MysqlDAOFactoryWithTestDB.crearConexio();
		}else {
			conn = MysqlDAOFactory.crearConexio();
		}
		ArrayList<String> categorias = new ArrayList<>();
		try {
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT NombreCategoria FROM categoria;");

			while(rs.next())
			{
				String nombreCategoria = rs.getString(1);
				categorias.add(nombreCategoria);
			}
			rs.close();
			stmt.close();
		}catch(SQLException e) {
			//TODO: log error sql
			logger.error("Error al cargar las categorias: " + e.getMessage());
		}
		return categorias;
	}

    public ArrayList<String> getTodosTipos(){

        logger.debug("Cargando datos de tipos");
        Connection conn = null;
        if(databaseTest == 1) {
            conn = MysqlDAOFactoryWithTestDB.crearConexio();
        }else {
            conn = MysqlDAOFactory.crearConexio();
        }
        ArrayList<String> tipos = new ArrayList<>();
        try {
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT Nombre FROM tipo;");

            while(rs.next())
            {
                String nombreCategoria = rs.getString(1);
                tipos.add(nombreCategoria);
            }
            rs.close();
            stmt.close();
        }catch(SQLException e) {
            //TODO: log error sql
            logger.error("Error al cargar los tipos: " + e.getMessage());
        }
        return tipos;
    }

	public ArrayList<Joc> carregarJocs() {
		logger.debug("Cargando datos de juegos");
		Connection conn = null;
		if(databaseTest == 1) {
			conn = MysqlDAOFactoryWithTestDB.crearConexio();
		}else {
			conn = MysqlDAOFactory.crearConexio();
		}
		ArrayList<Joc> jocs = new ArrayList<>();
		try {
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT J.idJuego, J.idCategoria, C.NombreCategoria, J.NombreJuego, J.Dificultad, J.Edad,J.Jugadores,J.Tiempo, T.Nombre, J.Descripcion, J.Valoracion, J.idTipo, J.Imagen, J.Materiales FROM juego J, categoria C,tipo T WHERE J.idCategoria=C.idCategoria AND J.idTipo=T.idTipo;");

			while(rs.next())
			{
				int idJuego=rs.getInt(1);
				int idCategoria=rs.getInt(2);
				String nombreCategoria = rs.getString(3);
				String nombreJuego=rs.getString(4);
				int dificultad = rs.getInt(5);
				int edat = rs.getInt(6);
				String numeroJugadores = rs.getString(7);
				String tiempo = rs.getString(8);
				String tipo = rs.getString(9);
				String descripcion = rs.getString(10);
				String valoracion = rs.getString(11);
				int idTipo =rs.getInt(12);
				String imagen = rs.getString(13);
				String materiales = rs.getString(14);
				Joc joc = new Joc(idJuego,idCategoria,nombreCategoria,nombreJuego,dificultad,edat, numeroJugadores,tiempo, tipo, descripcion,valoracion,idTipo, imagen, materiales);
				jocs.add(joc);
			}
			rs.close();
			stmt.close();
		}catch(SQLException e) {
			//TODO: log error sql
			logger.error("Error al cargar los juegos: " + e.getMessage());
		}
		return jocs;
	}

	public Joc buscarJocPerId(int idJoc){
        Connection conn = null;
        ResultSet rs;
        Usuari u = null;
        Joc joc = null;
        if(databaseTest == 1) {
            conn = MysqlDAOFactoryWithTestDB.crearConexio();
        }else {
            conn = MysqlDAOFactory.crearConexio();
        }
        try{
            Statement stmt = conn.createStatement();
            String queryStr = "SELECT J.idJuego, J.idCategoria, C.NombreCategoria, J.NombreJuego, J.Dificultad, J.Edad,J.Jugadores,J.Tiempo, T.Nombre, J.Descripcion, J.Valoracion, J.idTipo, J.Imagen, J.Materiales FROM juego J, categoria C,tipo T WHERE J.idCategoria=C.idCategoria AND J.idTipo=T.idTipo AND idJuego = ?";
            PreparedStatement pstmt = conn.prepareStatement(queryStr);
            pstmt.setInt(1, idJoc);
            rs = pstmt.executeQuery();
            while(rs.next())
            {
                int idJuego=rs.getInt(1);
                int idCategoria=rs.getInt(2);
                String nombreCategoria = rs.getString(3);
                String nombreJuego=rs.getString(4);
                int dificultad = rs.getInt(5);
                int edat = rs.getInt(6);
                String numeroJugadores = rs.getString(7);
                String tiempo = rs.getString(8);
                String tipo = rs.getString(9);
                String descripcion = rs.getString(10);
                String valoracion = rs.getString(11);
                int idTipo =rs.getInt(12);
                String imagen = rs.getString(13);
                String materiales = rs.getString(14);
                joc = new Joc(idJuego,idCategoria,nombreCategoria,nombreJuego,dificultad,edat, numeroJugadores,tiempo, tipo, descripcion,valoracion,idTipo, imagen, materiales);
            }

            stmt.close();
            rs.close();
        }catch(SQLException e) {
            //TODO: log error
            logger.error("*** ERROR SQL AL CARGAR LOS DATOS DE JUEGO ***" + e.getMessage());
        }

        return joc;
    }

	public Joc buscarJocPerNom(String nom){
		Connection conn = null;
		ResultSet rs;
		Usuari u = null;
		Joc joc = null;
		if(databaseTest == 1) {
			conn = MysqlDAOFactoryWithTestDB.crearConexio();
		}else {
			conn = MysqlDAOFactory.crearConexio();
		}
		try{
			Statement stmt = conn.createStatement();
			String queryStr = "SELECT J.idJuego, J.idCategoria, C.NombreCategoria, J.NombreJuego, J.Dificultad, J.Edad,J.Jugadores,J.Tiempo, T.Nombre, J.Descripcion, J.Valoracion, J.idTipo, J.Imagen, J.Materiales FROM juego J, categoria C,tipo T WHERE J.idCategoria=C.idCategoria AND J.idTipo=T.idTipo AND NombreJuego = ?";
			PreparedStatement pstmt = conn.prepareStatement(queryStr);
			pstmt.setString(1, nom);
			rs = pstmt.executeQuery();
			while(rs.next())
			{
				int idJuego=rs.getInt(1);
				int idCategoria=rs.getInt(2);
				String nombreCategoria = rs.getString(3);
				String nombreJuego=rs.getString(4);
				int dificultad = rs.getInt(5);
				int edat = rs.getInt(6);
				String numeroJugadores = rs.getString(7);
				String tiempo = rs.getString(8);
				String tipo = rs.getString(9);
				String descripcion = rs.getString(10);
				String valoracion = rs.getString(11);
				int idTipo =rs.getInt(12);
				String imagen = rs.getString(13);
				String materiales = rs.getString(14);
				joc = new Joc(idJuego,idCategoria,nombreCategoria,nombreJuego,dificultad,edat, numeroJugadores,tiempo, tipo, descripcion,valoracion,idTipo, imagen, materiales);
			}

			stmt.close();
			rs.close();
		}catch(SQLException e) {
			//TODO: log error
			logger.error("*** ERROR SQL AL CARGAR LOS DATOS DE JUEGO ***" + e.getMessage());
		}

		return joc;
	}

	public ArrayList<Joc> busquedaAvanzada(String nom , String nJugadors , String temps, String categoria , String genere)
	{
		ArrayList<Joc> JocsFiltrats = new ArrayList<Joc>();
		DAOFactory daoFactory = DAOFactory.getDAOFactory(DAOFactory.MYSQL);
		JocAlternatiuDAO jocAlternatiuDAO = daoFactory.getJocAlternatiuDAO();
		JocTaulaDAO jocTaulaDAO = daoFactory.getJocTaulaDAO();
		jocAlternatiuDAO.carregarJocsAlternatius();
		jocTaulaDAO.carregarJocsTaula();
		List<JocTaula> llistaJocsTaula = jocTaulaDAO.getLlistaJocsTaula();
		List<JocAlternatiu> llistaAlternatius = jocAlternatiuDAO.getLlistaJocsAlternatius();

		if(!nom.isEmpty())
		{
			boolean trobat = false;
			int x=0;
			int tamaño=llistaJocsTaula.size();
			while(!trobat)
			{
				if(llistaJocsTaula.get(x).getNomJoc().toLowerCase().equals(nom.toLowerCase()))
				{
					trobat=true;
					JocsFiltrats.add(llistaJocsTaula.get(x));
				}
				x++;
				if(x==tamaño && trobat==false)
				{
					trobat=true;
					System.out.println("no encontrado");
				}
			}

		}
		else
		{
			for(int x=0;x<llistaJocsTaula.size();x++)
			{
				JocsFiltrats.add(llistaJocsTaula.get(x));
			}
			for(int x=0;x<llistaAlternatius.size();x++)
			{
				JocsFiltrats.add(llistaAlternatius.get(x));
			}

			if(!categoria.isEmpty())
			{
				for(int x=0;x<JocsFiltrats.size();x++)
				{
					if(!JocsFiltrats.get(x).getNomCategoria().equals(categoria))
					{
						JocsFiltrats.remove(x);
						x=x-1;
					}
				}
			}
			if(!nJugadors.isEmpty())
			{
				int jugadorsperFiltre = Integer.parseInt(nJugadors);
				for(int x=0;x<JocsFiltrats.size();x++)
				{
					String jugadors=JocsFiltrats.get(x).getNumeroJugadors();
					String []nnjugadors=jugadors.split(" ");
					if(nnjugadors.length==1)
					{
						if(Integer.parseInt(nnjugadors[0])!=jugadorsperFiltre)
						{
							JocsFiltrats.remove(x);
							x=x-1;
						}
					}
					else
					{
						int nnjugadors1=Integer.parseInt(nnjugadors[0]);
						int nnjugadors2=Integer.parseInt(nnjugadors[1]);
						if(nnjugadors1>jugadorsperFiltre || nnjugadors2<jugadorsperFiltre)
						{
							JocsFiltrats.remove(x);
							x=x-1;
						}
					}

				}
			}
			if(!temps.isEmpty())
			{
				int tempsPerFiltre = Integer.parseInt(temps);
				for(int x=0;x<JocsFiltrats.size();x++)
				{
					String tempsS=JocsFiltrats.get(x).getDuracio();
					String []nTemps=tempsS.split(" ");
					if(nTemps.length==1)
					{
						if(Integer.parseInt(nTemps[0])!=tempsPerFiltre)
						{
							JocsFiltrats.remove(x);
							x=x-1;
						}
					}
					else
					{
						int nnjugadors1=Integer.parseInt(nTemps[0]);
						int nnjugadors2=Integer.parseInt(nTemps[1]);
						if(nnjugadors1>tempsPerFiltre || nnjugadors2<tempsPerFiltre)
						{
							JocsFiltrats.remove(x);
							x=x-1;
						}
					}

				}

			}
			if(!genere.isEmpty())
			{
				for(int x=0;x<JocsFiltrats.size();x++)
				{
					if(!JocsFiltrats.get(x).getTipo().equals(genere))
					{
						JocsFiltrats.remove(x);
						x=x-1;
					}
				}
			}
		}
		for(Joc j: JocsFiltrats)
		{
			System.out.println(j.getNomJoc());
		}

		return JocsFiltrats;
	}

	public ArrayList<Joc> carregarUltimsJocs() {
		logger.debug("Cargando novedades datos de juegos");
		Connection conn = null;
		if(databaseTest == 1) {
			conn = MysqlDAOFactoryWithTestDB.crearConexio();
		}else {
			conn = MysqlDAOFactory.crearConexio();
		}
		ArrayList<Joc> jocs = new ArrayList<>();
		try {
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT J.idJuego, J.idCategoria, C.NombreCategoria, J.NombreJuego, J.Dificultad, J.Edad,J.Jugadores,J.Tiempo, T.Nombre, J.Descripcion, J.Valoracion, J.idTipo, J.Imagen FROM juego J, categoria C,tipo T WHERE J.idCategoria=C.idCategoria AND J.idTipo=T.idTipo ORDER BY J.idJuego DESC LIMIT 10;");

			while(rs.next())
			{
				int idJuego=rs.getInt(1);
				int idCategoria=rs.getInt(2);
				String nombreCategoria = rs.getString(3);
				String nombreJuego=rs.getString(4);
				int dificultad = rs.getInt(5);
				int edat = rs.getInt(6);
				String numeroJugadores = rs.getString(7);
				String tiempo = rs.getString(8);
				String tipo = rs.getString(9);
				String descripcion = rs.getString(10);
				String valoracion = rs.getString(11);
				int idTipo =rs.getInt(12);
				String imagen = rs.getString(13);
				JocTaula joc = new JocTaula(idJuego,idCategoria,nombreCategoria,nombreJuego,dificultad,edat, numeroJugadores,tiempo, tipo, descripcion,valoracion,idTipo, imagen);
				jocs.add(joc);
			}
			rs.close();
			stmt.close();
		}catch(SQLException e) {
			//TODO: log error sql
			logger.error("Error al cargar los juegos de mesa: " + e.getMessage());
		}
		return jocs;
	}
}
