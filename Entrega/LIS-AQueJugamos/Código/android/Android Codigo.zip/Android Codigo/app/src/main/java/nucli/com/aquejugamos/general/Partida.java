package nucli.com.aquejugamos.general;

import java.util.ArrayList;


public class Partida {

    private int idPartida;
    private int juego;
    private int duracion;
    private String fecha;
    private boolean validada;
    private ArrayList<Usuari> participants;
    private ArrayList<String> comentarios;
    private int numJugadores;
    private String ganador;
    private String comentario;


    public Partida(int idPartida, int juego, int duracion, String fecha, boolean validada, ArrayList<Usuari> participants, ArrayList<String> comentarios, int numJugadores, String ganador) {
        this.idPartida = idPartida;
        this.juego = juego;
        this.duracion = duracion;
        this.fecha = fecha;
        this.validada = validada;
        this.participants = participants;
        this.comentarios = comentarios;
        this.numJugadores = numJugadores;
        this.ganador = ganador;
    }


    public Partida(int idPartida, int juego, int duracion, String fecha, int numJugadores, String ganador, String comentario) {
        this.idPartida = idPartida;
        this.juego = juego;
        this.duracion = duracion;
        this.fecha = fecha;
        this.validada = false;
        this.participants = new ArrayList<Usuari>();
        this.comentarios = new ArrayList<String>();
        this.numJugadores = numJugadores;
        this.ganador = ganador;
        this.setComentario(comentario);
    }

    public int getIdPartida() {
        return idPartida;
    }
    public void setIdPartida(int idPartida) {
        this.idPartida = idPartida;
    }
    public int getJuego() {
        return juego;
    }
    public void setJuego(int juego) {
        this.juego = juego;
    }
    public int getDuracion() {
        return duracion;
    }
    public void setDuracion(int duracion) {
        this.duracion = duracion;
    }
    public String getFecha() {
        return fecha;
    }
    public void setFecha(String fecha) {
        this.fecha = fecha;
    }
    public boolean isValidada() {
        return validada;
    }
    public void setValidada(boolean validada) {
        this.validada = validada;
    }
    public ArrayList<Usuari> getParticipants() {
        return participants;
    }
    public void setParticipants(ArrayList<Usuari> participants) {
        this.participants = participants;
    }

    public ArrayList<String> getComentarios() {
        return comentarios;
    }
    public void setComentarios(ArrayList<String> comentarios) {
        this.comentarios = comentarios;
    }
    public int getNumJugadores() {
        return numJugadores;
    }
    public void setNumJugadores(int numJugadores) {
        this.numJugadores = numJugadores;
    }
    public String getGanador() {
        return ganador;
    }
    public void setGanador(String ganador) {
        this.ganador = ganador;
    }

    public void afegirParticipant(Usuari u) {
        this.participants.add(u);
    }

    public String getComentario() {
        return comentario;
    }

    public void setComentario(String comentario) {
        this.comentario = comentario;
    }

}
