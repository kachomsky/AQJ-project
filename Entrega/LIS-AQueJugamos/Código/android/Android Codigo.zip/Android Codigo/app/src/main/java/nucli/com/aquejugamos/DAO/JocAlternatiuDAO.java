package nucli.com.aquejugamos.DAO;

import java.util.List;

import nucli.com.aquejugamos.general.JocAlternatiu;

public interface JocAlternatiuDAO {
	
	public void carregarJocsAlternatius();
	public List<JocAlternatiu> getLlistaJocsAlternatius();
	
}
