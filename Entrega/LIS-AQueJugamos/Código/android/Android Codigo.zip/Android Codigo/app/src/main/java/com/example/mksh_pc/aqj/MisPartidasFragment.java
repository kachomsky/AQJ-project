package com.example.mksh_pc.aqj;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import nucli.com.aquejugamos.DAO.DAOFactory;
import nucli.com.aquejugamos.DAO.JocDAO;
import nucli.com.aquejugamos.DAO.PartidaDAO;
import nucli.com.aquejugamos.general.Joc;
import nucli.com.aquejugamos.general.JocTaula;
import nucli.com.aquejugamos.general.Partida;

public class MisPartidasFragment extends Fragment {
    Map<Partida, Integer> partidas = null;
    ArrayList<Joc> jocs = new ArrayList<>();
    ArrayList<Partida> partidasJugadas = new ArrayList<>();
    ArrayList<Integer> ganadas = new ArrayList<>();

    public MisPartidasFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View view = null;
        SharedPreferences prefs = getActivity().getSharedPreferences("login", Context.MODE_PRIVATE);
        if (!prefs.getBoolean("isLogged", false)) {
            view = inflater.inflate(R.layout.msg_no_login, container, false);
            view.findViewById(R.id.iniciarSesionBtn).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Log.d("JUEGOSFRAGMENT", "Seleccionada opcion búsqueda");
                    startActivity(new Intent(getActivity(), Login.class));
                }
            });

            view.findViewById(R.id.registrarseBtn).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Log.d("JUEGOSFRAGMENT", "Seleccionada opcion búsqueda");
                    startActivity(new Intent(getActivity(), Registrarse.class));
                }
            });
        }else{

            view = inflater.inflate(R.layout.fragment_mis_partidas, container, false);
            SharedPreferences pref = getActivity().getSharedPreferences("login", Context.MODE_PRIVATE);

            int idUsuario = pref.getInt("id",0);

            try{
                Log.d("PARTIDAS", "El id del usuario a buscar es: " + idUsuario);
                partidas = new getPartidasUsuario(idUsuario).execute().get();
            }catch (Exception e){
                //todo
            }

            for (Map.Entry<Partida,Integer> entry : partidas.entrySet()){
                Log.d("PARTIDA", "Recorriendo el mapa en el fragmento");
                System.out.println(entry.getKey().getIdPartida() + "/" + entry.getValue());
            }

            for (Map.Entry<Partida,Integer> entry : partidas.entrySet())
            {
                Log.d("PARTIDAS", "Dentro del for de partidas");
                //System.out.println(entry.getKey() + "/" + entry.getValue());
                try{
                    Log.d("PARTIDAS", "La id de la partidas es: " + entry.getKey().getIdPartida());
                    Joc j = new getJuegoSeleccionado(entry.getKey().getJuego()).execute().get();
                    Log.d("PARTIDAS", "EL nombre del jeugo es: " + j.getNomJoc());
                    jocs.add(j);
                    partidasJugadas.add(entry.getKey());
                    ganadas.add(entry.getValue());
                }catch (Exception e){
                    Log.e("PARTIDA", e.getMessage());
                }

            }
            if(partidas != null){
                ListView listView = view.findViewById(R.id.listaPartidasUser);
                PartidasAdapter partidasAdapter = new PartidasAdapter(getActivity(), jocs);
                Log.d("PARTIDAS", "Las partidas de este user no son nulas: " + partidasAdapter.getCount());
                listView.setAdapter(partidasAdapter);
            }else{
                Log.d("PARTIDAS", "Las partidas de este usuario son nulas");

            }
        }


        return view;
    }

    private class getPartidasUsuario extends AsyncTask<Void, Void, Map> {
        private int idUsuario;

        public getPartidasUsuario(int idUsuario){
            this.idUsuario = idUsuario;
        }

        @Override
        protected Map doInBackground(Void... voids) {

            Log.d("HOME", "Cargando partidas de usuario");
            DAOFactory daoFactory = DAOFactory.getDAOFactory(DAOFactory.MYSQL);
            PartidaDAO partidaDAO= daoFactory.getPartidaDAO();
            Map<Partida, Integer> partidas = new HashMap<Partida, Integer>();
            try{
                partidas = partidaDAO.mostrarPartidesUsuari(this.idUsuario);
            }catch (Exception e){
                //todo
            }

            return partidas;
        }
    }

    public class PartidasAdapter extends ArrayAdapter<Joc> {

        public PartidasAdapter(@NonNull Context context, ArrayList<Joc> listaJuegos) {
            super(context, 0, listaJuegos);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent){
            Joc joc = getItem(position);
            Log.d("PARTIDAS", "dentro del getView de partidas");
            if (convertView == null) {
                Log.d("PARTIDAS", "no es nulo");
                convertView = LayoutInflater.from(getContext()).inflate(R.layout.fila_lista_partidas, parent, false);
            }

            TextView nombreJuego = (TextView) convertView.findViewById(R.id.nombreJuegoPartida);
            TextView fecha = (TextView) convertView.findViewById(R.id.fechaPartidas);
            TextView nJugadores = (TextView) convertView.findViewById(R.id.participantesPartidasSubida);
            Button boton = (Button) convertView.findViewById(R.id.victoriaTitulo);

            nombreJuego.setText(joc.getNomJoc());
            fecha.setText(partidasJugadas.get(position).getFecha());
            Log.d("PARTIDA", "El numero de participantes es: " + partidasJugadas.get(position).getNumJugadores());
            nJugadores.setText(String.valueOf(partidasJugadas.get(position).getNumJugadores()));

            if(ganadas.get(position) == 0){
                boton.setText("Derrota");
                boton.setBackgroundTintList(ColorStateList.valueOf(Color.RED));
            }

            return convertView;
        }
    }

    private class getJuegoSeleccionado extends AsyncTask<Void, Void, Joc> {

        private int idJuego;

        public getJuegoSeleccionado(int idJuego){
            this.idJuego = idJuego;
        }

        @Override
        protected Joc doInBackground(Void... voids) {
            Log.d("DETALLES JUEGO", "Cargando detalles juegos");
            DAOFactory daoFactory = DAOFactory.getDAOFactory(DAOFactory.MYSQL);
            JocDAO jocDAO = daoFactory.getJocDAO();
            Joc joc = jocDAO.buscarJocPerId(idJuego);
            return joc;
        }
    }
}